import art1 from "../assets/art-1.jpg";
import art2 from "../assets/art-2.jpg";
import art3 from "../assets/art-3.jpg";
import art4 from "../assets/art-4.jpg";
import art5 from "../assets/art-5.jpg";
import art6 from "../assets/art-6.jpg";

export const DEMO_ARTS = [art1, art2, art3, art4, art5, art6];

/* ---------------- Room constants (meters) ---------------- */
export const ROOM = {
  W: 8,      // X: -4..4
  L: 26,     // Z: -13..13
  H: 4.2,    // ceiling height
  PART_H: 2.7,
  PART_T: 0.14,
  EYE: 1.62,
  HANG: 1.58, // artwork center height
};

export interface Partition {
  id: string;
  x: number; z: number;
  w: number;             // length along local X
  rotY: number;          // radians
  label: string;
}

export const PARTITIONS: Partition[] = [
  { id: "PA",  x: -1.4, z: -9.5, w: 3.6, rotY: 0, label: "Перегородка A" },
  { id: "PA-r", x: 0.5, z: -10.4, w: 1.8, rotY: Math.PI / 2, label: "Перегородка A-⊥" },
  { id: "PB",  x: 2.5, z: -9.0, w: 1.6, rotY: 0, label: "Перегородка B" },
  { id: "PB-r", x: 1.7, z: -7.9, w: 2.0, rotY: Math.PI / 2, label: "Перегородка B-⊥" },
  { id: "C1",  x: -1.15, z: -4.6, w: 2.9, rotY: Math.PI / 2 - 0.32, label: "Дуга · сегмент 1" },
  { id: "C2",  x: -1.7, z: -2.0, w: 2.9, rotY: Math.PI / 2, label: "Дуга · сегмент 2" },
  { id: "C3",  x: -1.15, z: 0.6, w: 2.9, rotY: Math.PI / 2 + 0.32, label: "Дуга · сегмент 3" },
  { id: "PC",  x: 2.2, z: 3.0, w: 2.2, rotY: Math.PI / 2, label: "Пилон C" },
  { id: "PD",  x: -1.5, z: 6.5, w: 3.6, rotY: 0, label: "Перегородка D" },
  { id: "PD-r", x: -2.9, z: 7.7, w: 2.4, rotY: Math.PI / 2, label: "Перегородка D-⊥" },
  { id: "PE",  x: 2.3, z: 8.5, w: 1.8, rotY: 0, label: "Пилон E" },
];

export interface Bench { x: number; z: number; w: number; d: number; rotY: number }
export const BENCHES: Bench[] = [
  { x: 0.45, z: -1.6, w: 0.5, d: 1.9, rotY: 0 },
  { x: 0.45, z: 0.45, w: 0.5, d: 1.9, rotY: 0 },
  { x: 1.55, z: -0.55, w: 0.5, d: 1.9, rotY: Math.PI / 2 },
  { x: -1.5, z: 4.4, w: 0.5, d: 1.9, rotY: Math.PI / 2 },
];

/* ---------------- Artworks ---------------- */
export interface ArtworkDef {
  id: string;
  num: string;
  title: string;
  technique: string;
  w: number; h: number;      // meters
  x: number; y: number; z: number;
  rotY: number;
  zone: string;              // wall / partition label
  wall: "N" | "S" | "W" | "E" | "P";
  defaultImg: string | null;
  hue: number;               // placeholder accent
}

const Y = ROOM.HANG;

export const ARTWORKS: ArtworkDef[] = [
  { id: "AW01", num: "01", title: "Швейцарская сетка", technique: "Плакат · офсет 200 г/м²", w: 1.15, h: 0.85, x: -2.2, y: Y, z: -12.88, rotY: 0, zone: "Северная стена", wall: "N", defaultImg: art1, hue: 4 },
  { id: "AW02", num: "02", title: "Баухаус · Композиция", technique: "Плакат · шелкография", w: 1.0, h: 1.0, x: 0, y: Y, z: -12.88, rotY: 0, zone: "Северная стена", wall: "N", defaultImg: art2, hue: 45 },
  { id: "AW03", num: "03", title: "Хром · Жидкий металл", technique: "3D-рендер · фотопечать", w: 0.9, h: 1.2, x: 2.2, y: Y, z: -12.88, rotY: 0, zone: "Северная стена", wall: "N", defaultImg: art3, hue: 220 },
  { id: "AW04", num: "04", title: "Ма · Пустота", technique: "Плакат · цифровая печать", w: 0.85, h: 1.1, x: -3.88, y: Y, z: -11.0, rotY: Math.PI / 2, zone: "Западная стена", wall: "W", defaultImg: art4, hue: 30 },
  { id: "AW05", num: "05", title: "Градиент · Шум", technique: "Плакат · ризография", w: 0.95, h: 0.7, x: -2.2, y: Y, z: -9.42, rotY: 0, zone: "Перегородка A · юг", wall: "P", defaultImg: art5, hue: 300 },
  { id: "AW06", num: "06", title: "Глаз над пустыней", technique: "Фотоколлаж · фотопечать", w: 0.8, h: 0.8, x: -0.6, y: Y, z: -9.42, rotY: 0, zone: "Перегородка A · юг", wall: "P", defaultImg: art6, hue: 15 },
  { id: "AW07", num: "07", title: "Место для работы 07", technique: "Ваша техника · ваш размер", w: 1.1, h: 0.8, x: -1.4, y: Y, z: -9.58, rotY: Math.PI, zone: "Перегородка A · север", wall: "P", defaultImg: null, hue: 160 },
  { id: "AW08", num: "08", title: "Место для работы 08", technique: "Ваша техника · ваш размер", w: 1.2, h: 0.9, x: -3.88, y: Y, z: -6.5, rotY: Math.PI / 2, zone: "Западная стена", wall: "W", defaultImg: null, hue: 200 },
  { id: "AW09", num: "09", title: "Место для работы 09", technique: "Ваша техника · ваш размер", w: 0.9, h: 0.9, x: 2.5, y: Y, z: -8.92, rotY: 0, zone: "Перегородка B · юг", wall: "P", defaultImg: null, hue: 265 },
  { id: "AW10", num: "10", title: "Место для работы 10", technique: "Ваша техника · ваш размер", w: 0.8, h: 1.0, x: -1.07, y: Y, z: -4.57, rotY: Math.PI / 2 - 0.32, zone: "Дуга · сегмент 1", wall: "P", defaultImg: null, hue: 190 },
  { id: "AW11", num: "11", title: "Дуга · Центр", technique: "Плакат · цифровая печать", w: 0.9, h: 0.9, x: -1.62, y: Y, z: -2.0, rotY: Math.PI / 2, zone: "Дуга · сегмент 2", wall: "P", defaultImg: art6, hue: 15 },
  { id: "AW12", num: "12", title: "Место для работы 12", technique: "Ваша техника · ваш размер", w: 0.8, h: 1.0, x: -1.07, y: Y, z: 0.58, rotY: Math.PI / 2 + 0.32, zone: "Дуга · сегмент 3", wall: "P", defaultImg: null, hue: 100 },
  { id: "AW13", num: "13", title: "Место для работы 13", technique: "Ваша техника · ваш размер", w: 1.0, h: 0.75, x: -1.78, y: Y, z: -2.0, rotY: -Math.PI / 2, zone: "Дуга · оборот", wall: "P", defaultImg: null, hue: 330 },
  { id: "AW14", num: "14", title: "Место для работы 14", technique: "Ваша техника · ваш размер", w: 1.1, h: 0.85, x: -3.88, y: Y, z: -1.2, rotY: Math.PI / 2, zone: "Западная стена", wall: "W", defaultImg: null, hue: 55 },
  { id: "AW15", num: "15", title: "Место для работы 15", technique: "Ваша техника · ваш размер", w: 1.0, h: 0.75, x: 3.88, y: Y, z: -3.5, rotY: -Math.PI / 2, zone: "Восточная стена", wall: "E", defaultImg: null, hue: 140 },
  { id: "AW16", num: "16", title: "Место для работы 16", technique: "Ваша техника · ваш размер", w: 0.85, h: 1.1, x: 3.88, y: Y, z: 0.5, rotY: -Math.PI / 2, zone: "Восточная стена", wall: "E", defaultImg: null, hue: 210 },
  { id: "AW17", num: "17", title: "Место для работы 17", technique: "Ваша техника · ваш размер", w: 1.0, h: 0.8, x: 2.12, y: Y, z: 3.0, rotY: -Math.PI / 2, zone: "Пилон C · запад", wall: "P", defaultImg: null, hue: 20 },
  { id: "AW18", num: "18", title: "Место для работы 18", technique: "Ваша техника · ваш размер", w: 0.8, h: 0.8, x: 2.28, y: Y, z: 3.0, rotY: Math.PI / 2, zone: "Пилон C · восток", wall: "P", defaultImg: null, hue: 250 },
  { id: "AW19", num: "19", title: "Место для работы 19", technique: "Ваша техника · ваш размер", w: 1.15, h: 0.8, x: -2.3, y: Y, z: 6.42, rotY: Math.PI, zone: "Перегородка D · север", wall: "P", defaultImg: null, hue: 175 },
  { id: "AW20", num: "20", title: "Место для работы 20", technique: "Ваша техника · ваш размер", w: 0.9, h: 0.9, x: -0.7, y: Y, z: 6.42, rotY: Math.PI, zone: "Перегородка D · север", wall: "P", defaultImg: null, hue: 290 },
  { id: "AW21", num: "21", title: "Место для работы 21", technique: "Ваша техника · ваш размер", w: 1.2, h: 0.85, x: -1.5, y: Y, z: 6.58, rotY: 0, zone: "Перегородка D · юг", wall: "P", defaultImg: null, hue: 70 },
  { id: "AW22", num: "22", title: "Место для работы 22", technique: "Ваша техника · ваш размер", w: 1.2, h: 0.8, x: 2.3, y: Y, z: 8.42, rotY: Math.PI, zone: "Пилон E · север", wall: "P", defaultImg: null, hue: 120 },
  { id: "AW23", num: "23", title: "Место для работы 23", technique: "Ваша техника · ваш размер", w: 1.0, h: 1.0, x: 3.88, y: Y, z: 6.5, rotY: -Math.PI / 2, zone: "Восточная стена", wall: "E", defaultImg: null, hue: 0 },
  { id: "AW24", num: "24", title: "Место для работы 24", technique: "Ваша техника · ваш размер", w: 0.9, h: 1.2, x: -3.88, y: Y, z: 9.6, rotY: Math.PI / 2, zone: "Западная стена", wall: "W", defaultImg: null, hue: 230 },
];

/* ---------------- Tour nodes (точки перемещения) ---------------- */
export interface TourNode { id: string; name: string; sub: string; x: number; z: number; yaw: number }
export const NODES: TourNode[] = [
  { id: "N1", name: "Вход", sub: "Портал · 360°", x: 0, z: 11.3, yaw: 0 },
  { id: "N2", name: "Атриум", sub: "Пилоны D / E", x: 0, z: 7.4, yaw: 0 },
  { id: "N3", name: "Южный зал", sub: "Пилон C", x: 0.6, z: 3.6, yaw: -0.2 },
  { id: "N4", name: "Дуга", sub: "Радиусная стена", x: 1.35, z: -0.9, yaw: -0.55 },
  { id: "N5", name: "Северный зал", sub: "Галерея B", x: 0.4, z: -5.8, yaw: 0.12 },
  { id: "N6", name: "Дальний зал", sub: "Финал · 3 работы", x: 0.9, z: -11.2, yaw: 0.25 },
];

/* ---------------- Runtime artwork state (with user uploads) ---------------- */
export type MediaKind = "image" | "video";

export interface ArtworkState extends ArtworkDef {
  img: string | null;        // effective media (upload | default | null=placeholder)
  media?: MediaKind;         // тип загруженного медиа (undefined = картинка/плейсхолдер)
  customTitle?: string;
}

interface SavedMeta { img?: string; title?: string; video?: boolean }

export function initArtworkStates(): ArtworkState[] {
  try {
    const raw = localStorage.getItem("galerea-artworks-v1");
    const saved: Record<string, SavedMeta> = raw ? JSON.parse(raw) : {};
    return ARTWORKS.map((a) => {
      const s = saved[a.id];
      if (s?.video) {
        // видео догружается из IndexedDB отдельно (см. App hydration)
        return { ...a, img: null, media: "video" as const, customTitle: s.title };
      }
      return { ...a, img: s?.img ?? a.defaultImg, customTitle: s?.title };
    });
  } catch {
    return ARTWORKS.map((a) => ({ ...a, img: a.defaultImg }));
  }
}

export function persistArtworkStates(states: ArtworkState[]) {
  try {
    const obj: Record<string, SavedMeta> = {};
    for (const s of states) {
      const isCustomImg = s.img !== s.defaultImg;
      if (s.media === "video") {
        // сам видеофайл живёт в IndexedDB, здесь только метка
        if (isCustomImg || s.customTitle) {
          obj[s.id] = { video: true };
          if (s.customTitle) obj[s.id].title = s.customTitle;
        }
      } else if (isCustomImg || s.customTitle) {
        obj[s.id] = {};
        if (isCustomImg && s.img) obj[s.id].img = s.img;
        if (s.customTitle) obj[s.id].title = s.customTitle;
      }
    }
    localStorage.setItem("galerea-artworks-v1", JSON.stringify(obj));
  } catch {
    /* quota — ignore */
  }
}
