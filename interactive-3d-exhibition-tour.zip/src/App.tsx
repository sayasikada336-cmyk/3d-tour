import { useCallback, useEffect, useRef, useState } from "react";
import TourViewer from "./components/TourViewer";
import PlansView from "./components/PlansView";
import ArtworksManager from "./components/ArtworksManager";
import type { GalleryEngine } from "./engine/GalleryEngine";
import { initArtworkStates, persistArtworkStates, type ArtworkState, type MediaKind } from "./data/gallery";
import {
  readEmbeddedConfig, buildConfigAsync, applyConfig, parseConfigFile,
  injectConfig, getSourceHTML, downloadBlob, estimateMediaBytes, BASE_HTML_BYTES,
  isLocked, setPinLock, tryUnlock, relock,
} from "./utils/protect";
import { idbGet, idbSet, idbDel, cacheBlob, dropCache, formatMB } from "./utils/mediaStore";

type View = "tour" | "plans" | "works";

const LARGE_FILE_BYTES = 40 * 1024 * 1024;

export default function App() {
  const [embedded] = useState(() => readEmbeddedConfig());
  const [artworks, setArtworks] = useState<ArtworkState[]>(() => {
    const base = initArtworkStates();
    return embedded ? applyConfig(base, embedded) : base;
  });
  const [view, setView] = useState<View>("tour");
  const [focusedId, setFocusedId] = useState<string | null>(null);
  const [panoRequest, setPanoRequest] = useState<{ nodeId: string; t: number } | null>(null);
  const [focusRequest, setFocusRequest] = useState<{ artId: string; t: number } | null>(null);
  const [locked, setLocked] = useState<boolean>(() => !!embedded || isLocked());
  const [saving, setSaving] = useState(false);
  const engineRef = useRef<GalleryEngine | null>(null);

  const hardLock = !!embedded; // опубликованный файл — только просмотр

  useEffect(() => {
    engineRef.current?.setPaused(view !== "tour");
  }, [view]);

  /* Догрузка видеофайлов из IndexedDB после перезапуска */
  useEffect(() => {
    let live = true;
    (async () => {
      const pending = artworks.filter((a) => a.media === "video" && !a.img);
      for (const v of pending) {
        const blob = await idbGet(v.id);
        if (!live) return;
        if (blob && blob.size > 0) {
          const url = cacheBlob(v.id, blob);
          setArtworks((prev) => prev.map((a) => (a.id === v.id ? { ...a, img: url } : a)));
          engineRef.current?.setArtworkMedia(v.id, url, v.customTitle, "video");
        }
      }
    })();
    return () => { live = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const update = useCallback((fn: (prev: ArtworkState[]) => ArtworkState[]) => {
    setArtworks((prev) => {
      const next = fn(prev);
      if (!embedded) persistArtworkStates(next); // в опубликованном файле ничего не пишем
      return next;
    });
  }, [embedded]);

  const guard = useCallback(() => {
    if (locked) {
      alert("Выставка опубликована / заблокирована: менять работы и вставлять свои нельзя.");
      return true;
    }
    return false;
  }, [locked]);

  const handleUpload = useCallback((id: string, url: string, kind: MediaKind) => {
    if (locked) return;
    update((prev) => prev.map((a) => (a.id === id ? { ...a, img: url, media: kind } : a)));
    engineRef.current?.setArtworkMedia(id, url, undefined, kind);
  }, [update, locked]);

  const handleReset = useCallback((id: string) => {
    if (locked) return;
    const cur = artworks.find((a) => a.id === id);
    if (cur?.media === "video") {
      dropCache(id);
      void idbDel(id);
    }
    update((prev) => prev.map((a) => (a.id === id ? { ...a, img: a.defaultImg, media: undefined } : a)));
    engineRef.current?.setArtworkMedia(id, cur?.defaultImg ?? null, undefined, "image");
  }, [update, artworks, locked]);

  const handleTitle = useCallback((id: string, title: string) => {
    if (locked) return;
    const cur = artworks.find((a) => a.id === id);
    update((prev) => prev.map((a) => (a.id === id ? { ...a, customTitle: title } : a)));
    engineRef.current?.setArtworkMedia(id, cur?.img ?? null, title, cur?.media === "video" ? "video" : "image");
  }, [update, artworks, locked]);

  const handlePano = useCallback((nodeId: string) => {
    setView("tour");
    requestAnimationFrame(() => setPanoRequest({ nodeId, t: Date.now() }));
  }, []);

  const handleShowArt = useCallback((id: string) => {
    setView("tour");
    requestAnimationFrame(() => setFocusRequest({ artId: id, t: Date.now() }));
  }, []);

  /* ---------- защита ---------- */
  const handleSetPin = useCallback(async (pin: string) => {
    await setPinLock(pin);
    setLocked(true);
  }, []);

  const handleUnlock = useCallback(async (pin: string): Promise<boolean> => {
    const ok = await tryUnlock(pin);
    if (ok) setLocked(false);
    return ok;
  }, []);

  const handleRelock = useCallback(() => {
    relock();
    setLocked(true);
  }, []);

  /* ---------- файлы ---------- */
  const confirmSize = useCallback((totalBytes: number): boolean => {
    if (totalBytes < LARGE_FILE_BYTES) return true;
    return window.confirm(
      `Файл получится большим — примерно ${formatMB(totalBytes)}, т.к. видео вшиваются внутрь. Продолжить?`
    );
  }, []);

  const handleExportJSON = useCallback(async () => {
    const mediaBytes = estimateMediaBytes(artworks);
    if (!confirmSize(mediaBytes)) return;
    setSaving(true);
    try {
      const cfg = await buildConfigAsync(artworks);
      downloadBlob(new Blob([JSON.stringify(cfg)], { type: "application/json" }), "galerea-vystavka.json");
    } finally {
      setSaving(false);
    }
  }, [artworks, confirmSize]);

  const handleImportJSON = useCallback((file: File) => {
    if (guard()) return;
    const reader = new FileReader();
    reader.onload = async () => {
      const cfg = parseConfigFile(String(reader.result ?? ""));
      if (!cfg) {
        alert("Файл не распознан — нужен JSON, экспортированный из этой галереи.");
        return;
      }
      // видео из файла: dataURL -> blob в IndexedDB + objectURL для показа
      const fixedItems = await Promise.all(
        cfg.items.map(async (it) => {
          if (it.video && it.img && it.img.startsWith("data:video")) {
            try {
              const blob = await (await fetch(it.img)).blob();
              if (blob.size > 0) {
                dropCache(it.id);
                await idbSet(it.id, blob);
                const url = cacheBlob(it.id, blob);
                return { ...it, img: url };
              }
            } catch { /* оставляем как есть */ }
          }
          return it;
        })
      );
      const next = applyConfig(artworks, { ...cfg, items: fixedItems });
      update(() => next);
      next.forEach((s) =>
        engineRef.current?.setArtworkMedia(s.id, s.img ?? null, s.customTitle ?? "", s.media === "video" ? "video" : "image")
      );
    };
    reader.readAsText(file);
  }, [guard, artworks, update]);

  /** Публикация: упаковывает тур + все работы (фото и видео) в один
   *  защищённый HTML-файл, где уже никто ничего не сможет поменять. */
  const handleSaveFile = useCallback(async () => {
    const total = BASE_HTML_BYTES + Math.floor(estimateMediaBytes(artworks) * 1.37);
    if (!confirmSize(total)) return;
    setSaving(true);
    try {
      const cfg = await buildConfigAsync(artworks);
      const src = await getSourceHTML();
      const out = injectConfig(src, cfg);
      downloadBlob(new Blob([out], { type: "text/html" }), "galerea-exhibition.html");
    } finally {
      setSaving(false);
    }
  }, [artworks, confirmSize]);

  return (
    <div className="relative h-[100dvh] w-full overflow-hidden bg-[#0b0b0d] text-[#f5f2ec] no-select">
      <TourViewer
        artworks={artworks}
        onUpload={handleUpload}
        focusedId={focusedId}
        setFocusedId={setFocusedId}
        engineRef={engineRef}
        panoRequest={panoRequest}
        focusRequest={focusRequest}
        locked={locked || hardLock}
        onOpenPlans={() => setView("plans")}
        onOpenWorks={() => setView("works")}
      />
      {view === "plans" && (
        <PlansView
          artworks={artworks}
          onClose={() => setView("tour")}
          onPano={handlePano}
          onShowArt={handleShowArt}
        />
      )}
      {view === "works" && (
        <ArtworksManager
          artworks={artworks}
          onUpload={handleUpload}
          onReset={handleReset}
          onTitle={handleTitle}
          onShowArt={handleShowArt}
          onClose={() => setView("tour")}
          locked={locked}
          hardLock={hardLock}
          saving={saving}
          onExportJSON={handleExportJSON}
          onImportJSON={handleImportJSON}
          onSaveFile={handleSaveFile}
          onSetPin={handleSetPin}
          onUnlock={handleUnlock}
          onRelock={handleRelock}
        />
      )}
    </div>
  );
}
