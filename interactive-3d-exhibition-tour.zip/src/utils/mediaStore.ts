/* Хранилище медиа: видеофайлы в IndexedDB + objectURL-кэш.
   localStorage для видео не годится (квота ~5 МБ), а IDB держит сотни мегабайт. */

const DB_NAME = "galerea-media-v1";
const STORE = "videos";

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    try {
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => {
        if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE);
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    } catch (e) {
      reject(e);
    }
  });
}

function tx<T>(mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest): Promise<T> {
  return openDB().then(
    (db) =>
      new Promise<T>((resolve, reject) => {
        try {
          const t = db.transaction(STORE, mode);
          const req = fn(t.objectStore(STORE));
          req.onsuccess = () => {
            resolve(req.result as T);
            db.close();
          };
          req.onerror = () => {
            reject(req.error);
            db.close();
          };
        } catch (e) {
          db.close();
          reject(e);
        }
      })
  );
}

export function idbSet(id: string, blob: Blob): Promise<void> {
  return tx<void>("readwrite", (s) => s.put(blob, id)).catch(() => undefined);
}

export function idbGet(id: string): Promise<Blob | null> {
  return tx<unknown>("readonly", (s) => s.get(id))
    .then((r) => (r instanceof Blob ? r : null))
    .catch(() => null);
}

export function idbDel(id: string): Promise<void> {
  return tx<void>("readwrite", (s) => s.delete(id)).catch(() => undefined);
}

/* ---------- in-memory кэш ---------- */
const blobCache = new Map<string, Blob>();
const urlCache = new Map<string, string>();

export function cacheBlob(id: string, blob: Blob): string {
  const old = urlCache.get(id);
  if (old) URL.revokeObjectURL(old);
  blobCache.set(id, blob);
  const url = URL.createObjectURL(blob);
  urlCache.set(id, url);
  return url;
}

export function dropCache(id: string) {
  const old = urlCache.get(id);
  if (old) URL.revokeObjectURL(old);
  urlCache.delete(id);
  blobCache.delete(id);
}

export function getBlobSize(id: string): number {
  return blobCache.get(id)?.size ?? 0;
}

/** Достать dataURL видео для вставки в публикуемый файл. */
export async function getVideoDataURL(id: string, url: string | null): Promise<string | null> {
  let blob = blobCache.get(id);
  if (!blob && url) {
    try {
      const res = await fetch(url);
      const b = await res.blob();
      if (b.size > 0) blob = b;
    } catch {
      /* noop */
    }
  }
  if (!blob) blob = (await idbGet(id)) ?? undefined;
  if (!blob) return null;
  blobCache.set(id, blob);
  return blobToDataURL(blob);
}

export function blobToDataURL(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result));
    r.onerror = reject;
    r.readAsDataURL(blob);
  });
}

export const MAX_VIDEO_BYTES = 250 * 1024 * 1024;

export function formatMB(bytes: number): string {
  const mb = bytes / (1024 * 1024);
  return mb < 10 ? `${mb.toFixed(1)} МБ` : `${Math.round(mb)} МБ`;
}
