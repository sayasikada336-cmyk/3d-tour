import type { ArtworkState } from "../data/gallery";
import { getVideoDataURL, getBlobSize } from "./mediaStore";

/* ---------- Встроенная конфигурация выставки ---------- */
export interface SavedItem { id: string; img: string | null; title?: string; video?: boolean }
export interface EmbeddedConfig {
  app: "galerea";
  version: 1;
  locked: true;
  exportedAt: string;
  items: SavedItem[];
}

export function readEmbeddedConfig(): EmbeddedConfig | null {
  try {
    const el = document.getElementById("galerea-embedded");
    if (!el?.textContent) return null;
    const cfg = JSON.parse(el.textContent);
    if (cfg?.app === "galerea" && Array.isArray(cfg.items)) return cfg as EmbeddedConfig;
    return null;
  } catch {
    return null;
  }
}

/** Асинхронная сборка: видео подтягиваются из кэша/IDB и вшиваются как dataURL. */
export async function buildConfigAsync(states: ArtworkState[]): Promise<EmbeddedConfig> {
  const items: SavedItem[] = await Promise.all(
    states.map(async (s) => {
      if (s.media === "video") {
        const data = await getVideoDataURL(s.id, s.img);
        return {
          id: s.id,
          img: data,
          video: true as const,
          ...(s.customTitle ? { title: s.customTitle } : {}),
        };
      }
      return {
        id: s.id,
        img: s.img ?? null,
        ...(s.customTitle ? { title: s.customTitle } : {}),
      };
    })
  );
  return { app: "galerea", version: 1, locked: true, exportedAt: new Date().toISOString(), items };
}

export function applyConfig(base: ArtworkState[], cfg: EmbeddedConfig): ArtworkState[] {
  const map = new Map(cfg.items.map((i) => [i.id, i]));
  return base.map((a) => {
    const s = map.get(a.id);
    if (!s) return a;
    return {
      ...a,
      img: s.img ?? a.defaultImg,
      media: s.video ? ("video" as const) : undefined,
      customTitle: s.title,
    };
  });
}

/** Примерный вес медиа в байтах (для оценки размера публикуемого файла). */
export function estimateMediaBytes(states: ArtworkState[]): number {
  let n = 0;
  for (const s of states) {
    if (s.media === "video") n += getBlobSize(s.id);
    else if (s.img && s.img !== s.defaultImg) n += Math.floor(s.img.length * 0.75);
  }
  return n;
}

/** Вес самого приложения (одним файлом) — для оценки итога публикации. */
export const BASE_HTML_BYTES = 3_000_000;

export function parseConfigFile(text: string): EmbeddedConfig | null {
  try {
    const j = JSON.parse(text);
    const items = Array.isArray(j) ? j : j.items;
    if (!Array.isArray(items)) return null;
    const clean: SavedItem[] = [];
    for (const it of items) {
      if (!it || typeof it.id !== "string") continue;
      const img =
        typeof it.img === "string" && /^(data:(image|video)\/|https?:|blob:)/.test(it.img) ? it.img : null;
      clean.push({
        id: it.id,
        img,
        ...(it.video === true ? { video: true as const } : {}),
        ...(typeof it.title === "string" && it.title ? { title: it.title.slice(0, 80) } : {}),
      });
    }
    if (!clean.length) return null;
    return { app: "galerea", version: 1, locked: true, exportedAt: String(j.exportedAt ?? ""), items: clean };
  } catch {
    return null;
  }
}

/* ---------- Упаковка защищённого HTML-файла ---------- */
export function injectConfig(html: string, cfg: EmbeddedConfig): string {
  const clean = html.replace(/<script id="galerea-embedded"[^>]*>[\s\S]*?<\/script>/, "");
  const json = JSON.stringify(cfg).replace(/</g, "\\u003c");
  const tag = `<script id="galerea-embedded" type="application/json">${json}<\/script>`;
  if (clean.includes("</body>")) return clean.replace("</body>", `${tag}</body>`);
  return clean + tag;
}

export async function getSourceHTML(): Promise<string> {
  try {
    const res = await fetch(window.location.href, { cache: "force-cache" });
    if (res.ok) {
      const t = await res.text();
      if (t.includes('id="root"') || t.includes("id='root'")) return t;
    }
  } catch {
    /* file:// — берём живой DOM */
  }
  const clone = document.documentElement.cloneNode(true) as HTMLElement;
  clone.querySelector("#root")!.innerHTML = "";
  clone.querySelector("#galerea-embedded")?.remove();
  clone.querySelectorAll("canvas").forEach((c) => c.remove());
  return "<!doctype html>\n" + clone.outerHTML;
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 8000);
}

/* ---------- PIN-замок (для своего устройства) ---------- */
const LOCK_KEY = "galerea-lock-v1";
interface LockRec { hash: string; locked: boolean }

async function hashPin(pin: string): Promise<string> {
  try {
    if (window.crypto?.subtle) {
      const buf = await window.crypto.subtle.digest("SHA-256", new TextEncoder().encode("galerea|" + pin));
      return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
    }
  } catch {
    /* fallback ниже */
  }
  let h = 5381;
  const s = "galerea|" + pin;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0;
  return "dj" + (h >>> 0).toString(16);
}

function readLock(): LockRec | null {
  try {
    const raw = localStorage.getItem(LOCK_KEY);
    if (!raw) return null;
    const j = JSON.parse(raw);
    if (typeof j.hash === "string") return j as LockRec;
    return null;
  } catch {
    return null;
  }
}

export function isLocked(): boolean {
  return !!readLock()?.locked;
}
export function hasPin(): boolean {
  return !!readLock()?.hash;
}
export async function setPinLock(pin: string): Promise<void> {
  const hash = await hashPin(pin);
  try {
    localStorage.setItem(LOCK_KEY, JSON.stringify({ hash, locked: true }));
  } catch { /* noop */ }
}
export async function tryUnlock(pin: string): Promise<boolean> {
  const rec = readLock();
  if (!rec) return false;
  const h = await hashPin(pin);
  if (h === rec.hash) {
    try {
      localStorage.setItem(LOCK_KEY, JSON.stringify({ hash: rec.hash, locked: false }));
    } catch { /* noop */ }
    return true;
  }
  return false;
}
export function relock(): void {
  const rec = readLock();
  if (rec?.hash) {
    try {
      localStorage.setItem(LOCK_KEY, JSON.stringify({ hash: rec.hash, locked: true }));
    } catch { /* noop */ }
  }
}
