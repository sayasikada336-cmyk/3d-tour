import * as THREE from "three";

/* ---------- Дубовый пол: процедурные доски ---------- */
export function makeWoodFloorTexture(): THREE.CanvasTexture {
  const S = 1024;
  const c = document.createElement("canvas");
  c.width = S; c.height = S;
  const g = c.getContext("2d")!;
  g.fillStyle = "#b98f5f";
  g.fillRect(0, 0, S, S);

  const planks = 8;
  const pw = S / planks;
  for (let p = 0; p < planks; p++) {
    const tone = 0.86 + Math.random() * 0.26;
    const base: [number, number, number] = [196 * tone, 154 * tone, 108 * tone];
    g.fillStyle = `rgb(${base[0] | 0},${base[1] | 0},${base[2] | 0})`;
    g.fillRect(p * pw, 0, pw, S);

    // древесные волокна
    for (let i = 0; i < 46; i++) {
      const x = p * pw + Math.random() * pw;
      const alpha = 0.04 + Math.random() * 0.1;
      const dark = Math.random() > 0.4;
      g.strokeStyle = dark ? `rgba(90,60,30,${alpha})` : `rgba(255,235,200,${alpha})`;
      g.lineWidth = 0.6 + Math.random() * 1.6;
      g.beginPath();
      let xx = x;
      g.moveTo(xx, -10);
      for (let y = 0; y <= S; y += 32) {
        xx += (Math.random() - 0.5) * 7;
        g.lineTo(xx, y);
      }
      g.stroke();
    }
    // пара сучков
    if (Math.random() > 0.35) {
      const kx = p * pw + pw * (0.3 + Math.random() * 0.4);
      const ky = Math.random() * S;
      for (let r = 7; r > 0; r -= 1.6) {
        g.strokeStyle = `rgba(80,52,26,${0.16 + (7 - r) * 0.03})`;
        g.lineWidth = 1.4;
        g.beginPath();
        g.ellipse(kx, ky, r * 0.8, r * 1.5, 0, 0, Math.PI * 2);
        g.stroke();
      }
    }
    // стыки досок по длине
    const joints = 2 + ((Math.random() * 2) | 0);
    for (let j = 1; j <= joints; j++) {
      const y = (S / (joints + 1)) * j + (Math.random() - 0.5) * 60;
      g.fillStyle = "rgba(70,45,22,0.55)";
      g.fillRect(p * pw, y, pw, 2);
      g.fillStyle = "rgba(255,240,210,0.18)";
      g.fillRect(p * pw, y + 2, pw, 1);
    }
    // кромка
    g.fillStyle = "rgba(60,38,18,0.6)";
    g.fillRect(p * pw, 0, 2, S);
    g.fillStyle = "rgba(255,240,210,0.14)";
    g.fillRect(p * pw + 2, 0, 2, S);
  }
  // лёгкий шум-лак
  for (let i = 0; i < 2600; i++) {
    g.fillStyle = `rgba(${Math.random() > 0.5 ? "255,240,215" : "60,40,20"},${Math.random() * 0.05})`;
    g.fillRect(Math.random() * S, Math.random() * S, 2, 2);
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  return tex;
}

/* ---------- Плейсхолдер работы: стильная графическая заглушка ---------- */
export function makePlaceholderCanvas(num: string, w: number, h: number, hue: number, title: string): HTMLCanvasElement {
  const W = 768, H = Math.round(768 * (h / w));
  const c = document.createElement("canvas");
  c.width = W; c.height = H;
  const g = c.getContext("2d")!;

  const bg = g.createLinearGradient(0, 0, W, H);
  bg.addColorStop(0, `hsl(${hue}, 26%, 93%)`);
  bg.addColorStop(0.55, `hsl(${(hue + 24) % 360}, 30%, 86%)`);
  bg.addColorStop(1, `hsl(${(hue + 60) % 360}, 32%, 78%)`);
  g.fillStyle = bg;
  g.fillRect(0, 0, W, H);

  // сетка
  g.strokeStyle = `hsla(${hue},30%,40%,0.18)`;
  g.lineWidth = 1;
  for (let x = 0; x < W; x += 48) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x, H); g.stroke(); }
  for (let y = 0; y < H; y += 48) { g.beginPath(); g.moveTo(0, y); g.lineTo(W, y); g.stroke(); }

  // крупные фигуры
  g.fillStyle = `hsla(${hue},55%,32%,0.85)`;
  g.beginPath(); g.arc(W * 0.72, H * 0.3, Math.min(W, H) * 0.16, 0, Math.PI * 2); g.fill();
  g.fillStyle = `hsla(${(hue + 140) % 360},60%,30%,0.7)`;
  g.fillRect(W * 0.12, H * 0.58, W * 0.3, H * 0.045);
  g.fillRect(W * 0.12, H * 0.65, W * 0.2, H * 0.045);
  g.strokeStyle = `hsla(${hue},55%,25%,0.8)`;
  g.lineWidth = 6;
  g.strokeRect(W * 0.12, H * 0.12, W * 0.34, H * 0.3);

  // номер
  g.fillStyle = `hsla(${hue},45%,22%,0.92)`;
  g.font = `800 ${Math.round(H * 0.16)}px Inter, sans-serif`;
  g.fillText(num, W * 0.1, H * 0.47);

  // подписи
  g.fillStyle = "rgba(20,18,16,0.85)";
  g.font = `600 ${Math.round(H * 0.042)}px Inter, sans-serif`;
  const short = title.length > 26 ? title.slice(0, 26) + "…" : title;
  g.fillText(short.toUpperCase(), W * 0.12, H * 0.82);
  g.font = `${Math.round(H * 0.028)}px Inter, sans-serif`;
  g.fillStyle = "rgba(20,18,16,0.6)";
  g.fillText("МЕСТО ДЛЯ ВАШЕЙ РАБОТЫ · НАЖМИТЕ «ЗАМЕНИТЬ»", W * 0.12, H * 0.875);
  g.fillText(`${w.toFixed(2)} × ${h.toFixed(2)} М · 300 DPI`, W * 0.12, H * 0.92);

  // рамка-метка углов
  g.strokeStyle = "rgba(20,18,16,0.5)";
  g.lineWidth = 3;
  const m = 22, L = 46;
  const corners: [number, number, number, number][] = [[m, m, 1, 1], [W - m, m, -1, 1], [m, H - m, 1, -1], [W - m, H - m, -1, -1]];
  for (const [x, y, dx, dy] of corners) {
    g.beginPath();
    g.moveTo(x + L * dx, y); g.lineTo(x, y); g.lineTo(x, y + L * dy);
    g.stroke();
  }
  return c;
}

export function makePlaceholderTexture(num: string, w: number, h: number, hue: number, title: string): THREE.CanvasTexture {
  const tex = new THREE.CanvasTexture(makePlaceholderCanvas(num, w, h, hue, title));
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  return tex;
}

export function placeholderDataURL(num: string, w: number, h: number, hue: number, title: string): string {
  return makePlaceholderCanvas(num, w, h, hue, title).toDataURL("image/jpeg", 0.85);
}

/* ---------- Табличка у работы ---------- */
export function makeLabelTexture(num: string, title: string): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = 512; c.height = 192;
  const g = c.getContext("2d")!;
  g.fillStyle = "#faf8f4";
  g.fillRect(0, 0, 512, 192);
  g.fillStyle = "#111";
  g.font = "600 44px 'JetBrains Mono', monospace";
  g.fillText(num, 32, 62);
  g.font = "500 30px Inter, sans-serif";
  const t = title.length > 24 ? title.slice(0, 24) + "…" : title;
  g.fillText(t, 32, 112);
  g.font = "400 24px Inter, sans-serif";
  g.fillStyle = "#666";
  g.fillText("Графический дизайн · 2026", 32, 150);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

/* ---------- Сжать загруженное фото до разумного размера ---------- */
export function downscaleImage(dataUrl: string, maxSize = 1600, quality = 0.88): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      let { width, height } = img;
      const scale = Math.min(1, maxSize / Math.max(width, height));
      width = Math.round(width * scale);
      height = Math.round(height * scale);
      const c = document.createElement("canvas");
      c.width = width; c.height = height;
      c.getContext("2d")!.drawImage(img, 0, 0, width, height);
      resolve(c.toDataURL("image/jpeg", quality));
    };
    img.onerror = reject;
    img.src = dataUrl;
  });
}
