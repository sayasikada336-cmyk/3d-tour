import * as THREE from "three";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import { ROOM, PARTITIONS, BENCHES, NODES, type ArtworkState, type TourNode } from "../data/gallery";
import { makeWoodFloorTexture, makePlaceholderTexture, makeLabelTexture } from "../utils/textures";

export interface Hotspot {
  id: string;
  sx: number; // px
  sy: number; // px
  visible: boolean;
  dist: number;
}

export interface EngineCallbacks {
  onHotspots: (arts: Hotspot[], nodes: Hotspot[]) => void;
  onMove: (x: number, z: number, yaw: number, pitch: number) => void;
  onFocus: (id: string | null) => void;
  onReady: () => void;
}

interface Collider { x: number; z: number; hx: number; hz: number; rot: number }
interface Tween {
  t: number; dur: number;
  update: (k: number) => void;
  done?: () => void;
  ease: (k: number) => number;
  tag: string;
}

const easeInOut = (k: number) => (k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2);
const easeOutExpo = (k: number) => (k >= 1 ? 1 : 1 - Math.pow(2, -10 * k));

const normAngle = (a: number) => {
  while (a > Math.PI) a -= Math.PI * 2;
  while (a < -Math.PI) a += Math.PI * 2;
  return a;
};
const nearestAngle = (from: number, to: number) => from + normAngle(to - from);

export class GalleryEngine {
  private container: HTMLElement;
  private cb: EngineCallbacks;
  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private clock = new THREE.Clock();
  private raf = 0;
  private paused = false;

  // state
  private yaw = 0;
  private pitch = 0;
  private tYaw = 0;
  private tPitch = 0;
  private keys = new Set<string>();
  private joy = { x: 0, y: 0 };
  private dragging = false;
  private lastPX = 0; private lastPY = 0;
  private downX = 0; private downY = 0; private downT = 0;
  private lastInteract = 0;
  private bobPhase = 0;
  private tweens: Tween[] = [];
  private focusedId: string | null = null;
  private savedView: { x: number; z: number; yaw: number; pitch: number } | null = null;
  private autoRotate = false;
  private isMobile = false;

  // gyro
  private gyro = false;
  private gyroBase: { a: number; b: number } | null = null;
  private gyroYaw0 = 0; private gyroPitch0 = 0;

  // scene refs
  private states: ArtworkState[] = [];
  private artGroups = new Map<string, { group: THREE.Group; imgMat: THREE.MeshStandardMaterial; labelMat: THREE.MeshBasicMaterial; def: ArtworkState; center: THREE.Vector3; normal: THREE.Vector3 }>();
  private hitMeshes: THREE.Object3D[] = [];
  private occluders: THREE.Object3D[] = [];
  private nodeMarkers: { node: TourNode; ring: THREE.Mesh; pos: THREE.Vector3 }[] = [];
  private colliders: Collider[] = [];
  private raycaster = new THREE.Raycaster();
  private tmpV = new THREE.Vector3();
  private loader = new THREE.TextureLoader();
  private videos = new Map<string, HTMLVideoElement>();
  private resizeObs: ResizeObserver | null = null;
  private moveTick = 0;
  private occlusionCache = new Map<string, boolean>();
  private occTick = 0;

  constructor(container: HTMLElement, states: ArtworkState[], cb: EngineCallbacks) {
    this.container = container;
    this.states = states;
    this.cb = cb;
    this.isMobile = window.matchMedia("(pointer: coarse)").matches || window.innerWidth < 768;
    const n0 = NODES[0];
    this.yaw = this.tYaw = n0.yaw;
  }

  /* ================= INIT ================= */
  init() {
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;

    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
    this.renderer.setSize(w, h);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, this.isMobile ? 1.6 : 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.12;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.domElement.style.touchAction = "none";
    this.renderer.domElement.style.display = "block";
    this.container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0b0b0d);
    this.scene.fog = new THREE.Fog(0x0b0b0d, 34, 70);

    this.camera = new THREE.PerspectiveCamera(this.isMobile ? 74 : 66, w / h, 0.05, 120);
    this.camera.rotation.order = "YXZ";
    const n0 = NODES[0];
    this.camera.position.set(n0.x, ROOM.EYE, n0.z);

    // environment for PBR sheen
    try {
      const pmrem = new THREE.PMREMGenerator(this.renderer);
      this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.06).texture;
      if ("environmentIntensity" in this.scene) (this.scene as unknown as { environmentIntensity: number }).environmentIntensity = 0.32;
    } catch { /* noop */ }

    this.buildLights();
    this.buildRoom();
    this.buildPartitions();
    this.buildBenches();
    this.buildFigures();
    this.buildArtworks();
    this.buildNodes();
    this.buildColliders();

    this.bindEvents();
    this.loop();
    this.cb.onReady();
  }

  /* ================= BUILD ================= */
  private buildLights() {
    this.scene.add(new THREE.HemisphereLight(0xfff5e6, 0x4a3d30, 0.85));
    this.scene.add(new THREE.AmbientLight(0xffffff, 0.32));

    const downs: [number, number][] = [[0, -9], [0, -3], [0, 3], [0, 9]];
    downs.forEach(([x, z], i) => {
      const s = new THREE.SpotLight(0xfff2df, 55, 12, 0.95, 0.9, 1.8);
      s.position.set(x, ROOM.H - 0.05, z);
      s.target.position.set(x, 0, z);
      if (i === 1 || i === 3) {
        s.castShadow = true;
        s.shadow.mapSize.set(this.isMobile ? 512 : 1024, this.isMobile ? 512 : 1024);
        s.shadow.bias = -0.0004;
      }
      this.scene.add(s, s.target);
    });
  }

  private wallMat() {
    return new THREE.MeshStandardMaterial({ color: 0xf3efe7, roughness: 0.96, metalness: 0 });
  }

  private buildRoom() {
    const { W, L, H } = ROOM;
    // floor
    const floorTex = makeWoodFloorTexture();
    floorTex.repeat.set(7, 4);
    const floor = new THREE.Mesh(
      new THREE.PlaneGeometry(W, L),
      new THREE.MeshStandardMaterial({ map: floorTex, roughness: 0.55, metalness: 0.06, envMapIntensity: 0.5 })
    );
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    this.scene.add(floor);

    // outer dark ground (like model photo table)
    const outer = new THREE.Mesh(
      new THREE.PlaneGeometry(120, 120),
      new THREE.MeshStandardMaterial({ color: 0x101013, roughness: 1 })
    );
    outer.rotation.x = -Math.PI / 2;
    outer.position.y = -0.02;
    this.scene.add(outer);

    const wm = this.wallMat();
    const mkWall = (w: number, h: number, d: number, x: number, y: number, z: number) => {
      const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), wm);
      m.position.set(x, y, z);
      m.receiveShadow = true; m.castShadow = true;
      this.scene.add(m); this.occluders.push(m);
      return m;
    };
    // north (back)
    mkWall(W + 0.4, H, 0.2, 0, H / 2, -L / 2 - 0.1);
    // west / east
    mkWall(0.2, H, L + 0.4, -W / 2 - 0.1, H / 2, 0);
    mkWall(0.2, H, L + 0.4, W / 2 + 0.1, H / 2, 0);
    // south with door opening (door 2m wide, 2.6 high)
    mkWall(W / 2 - 1 + 0.2, H, 0.2, -(1 + (W / 2 - 1) / 2), H / 2, L / 2 + 0.1);
    mkWall(W / 2 - 1 + 0.2, H, 0.2, 1 + (W / 2 - 1) / 2, H / 2, L / 2 + 0.1);
    mkWall(2.2, H - 2.6, 0.2, 0, 2.6 + (H - 2.6) / 2, L / 2 + 0.1);
    // dark lobby behind door + glow sign
    const lobby = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 2.8), new THREE.MeshBasicMaterial({ color: 0x060607 }));
    lobby.position.set(0, 1.4, L / 2 + 0.65);
    lobby.rotation.y = Math.PI;
    this.scene.add(lobby);
    const signCanvas = document.createElement("canvas");
    signCanvas.width = 512; signCanvas.height = 128;
    const sg = signCanvas.getContext("2d")!;
    sg.fillStyle = "#0b0b0d"; sg.fillRect(0, 0, 512, 128);
    sg.fillStyle = "#e8e2d4"; sg.font = "600 56px Inter, sans-serif";
    sg.textAlign = "center"; sg.fillText("ВЫХОД · EXIT", 256, 84);
    const signTex = new THREE.CanvasTexture(signCanvas);
    signTex.colorSpace = THREE.SRGBColorSpace;
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(1.1, 0.28), new THREE.MeshBasicMaterial({ map: signTex }));
    sign.position.set(0, 2.85, L / 2 - 0.02);
    sign.rotation.y = Math.PI;
    this.scene.add(sign);

    // ceiling
    const ceil = new THREE.Mesh(
      new THREE.PlaneGeometry(W + 0.4, L + 0.4),
      new THREE.MeshStandardMaterial({ color: 0xf8f5ee, roughness: 0.95 })
    );
    ceil.rotation.x = Math.PI / 2;
    ceil.position.y = H;
    this.scene.add(ceil);

    // LED strips
    const ledMat = new THREE.MeshBasicMaterial({ color: 0xfff6e6 });
    [-2.3, 2.3].forEach((x) => {
      const led = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.03, L - 2), ledMat);
      led.position.set(x, H - 0.02, 0);
      this.scene.add(led);
    });
    // track rails + heads
    const railMat = new THREE.MeshStandardMaterial({ color: 0x1a1a1c, roughness: 0.6, metalness: 0.4 });
    [-1.3, 1.3].forEach((x) => {
      const rail = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.06, L - 3), railMat);
      rail.position.set(x, H - 0.09, 0);
      this.scene.add(rail);
      for (let z = -11; z <= 11; z += 2.2) {
        const head = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.06, 0.16, 12), railMat);
        head.position.set(x, H - 0.2, z);
        head.rotation.z = x > 0 ? -0.35 : 0.35;
        this.scene.add(head);
        const lens = new THREE.Mesh(new THREE.CircleGeometry(0.038, 12), new THREE.MeshBasicMaterial({ color: 0xffedc4 }));
        lens.position.set(x + (x > 0 ? -0.035 : 0.035), H - 0.27, z);
        lens.rotation.x = Math.PI / 2;
        lens.rotation.z = x > 0 ? -0.35 : 0.35;
        this.scene.add(lens);
      }
    });

    // skirting
    const skirtMat = new THREE.MeshStandardMaterial({ color: 0x26262a, roughness: 0.7 });
    const skirt = (w: number, d: number, x: number, z: number) => {
      const m = new THREE.Mesh(new THREE.BoxGeometry(w, 0.09, d), skirtMat);
      m.position.set(x, 0.045, z);
      this.scene.add(m);
    };
    skirt(W, 0.03, 0, -L / 2 + 0.015);
    skirt(0.03, L, -W / 2 + 0.015, 0);
    skirt(0.03, L, W / 2 - 0.015, 0);
    skirt(W / 2 - 1, 0.03, -(1 + (W / 2 - 1) / 2), L / 2 - 0.015);
    skirt(W / 2 - 1, 0.03, 1 + (W / 2 - 1) / 2, L / 2 - 0.015);
  }

  private buildPartitions() {
    const mat = new THREE.MeshStandardMaterial({ color: 0xf5f2eb, roughness: 0.95 });
    for (const p of PARTITIONS) {
      const m = new THREE.Mesh(new THREE.BoxGeometry(p.w, ROOM.PART_H, ROOM.PART_T), mat);
      m.position.set(p.x, ROOM.PART_H / 2, p.z);
      m.rotation.y = p.rotY;
      m.castShadow = true; m.receiveShadow = true;
      this.scene.add(m); this.occluders.push(m);
      // top edge shadow gap
      const cap = new THREE.Mesh(
        new THREE.BoxGeometry(p.w, 0.025, ROOM.PART_T + 0.005),
        new THREE.MeshStandardMaterial({ color: 0xe4ded2, roughness: 0.9 })
      );
      cap.position.set(p.x, ROOM.PART_H + 0.012, p.z);
      cap.rotation.y = p.rotY;
      this.scene.add(cap);
    }
  }

  private buildBenches() {
    const leather = new THREE.MeshStandardMaterial({ color: 0x131316, roughness: 0.45, metalness: 0.15 });
    const steel = new THREE.MeshStandardMaterial({ color: 0x8a8d92, roughness: 0.3, metalness: 0.9 });
    for (const b of BENCHES) {
      const grp = new THREE.Group();
      const seat = new THREE.Mesh(new THREE.BoxGeometry(b.w, 0.16, b.d), leather);
      seat.position.y = 0.42;
      seat.castShadow = true; seat.receiveShadow = true;
      grp.add(seat);
      const base = new THREE.Mesh(new THREE.BoxGeometry(b.w - 0.1, 0.3, b.d - 0.3), leather);
      base.position.y = 0.2;
      grp.add(base);
      [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sz]) => {
        const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.1, 10), steel);
        leg.position.set(sx * (b.w / 2 - 0.06), 0.05, sz * (b.d / 2 - 0.12));
        grp.add(leg);
      });
      grp.position.set(b.x, 0, b.z);
      grp.rotation.y = b.rotY;
      this.scene.add(grp);
    }
  }

  private buildFigures() {
    // Зал остаётся пустым: без фигурок людей и без входной стойки с описанием.
  }

  private buildArtworks() {
    const frameMat = new THREE.MeshStandardMaterial({ color: 0x17171a, roughness: 0.35, metalness: 0.65 });
    const matWhite = new THREE.MeshStandardMaterial({ color: 0xfbf9f5, roughness: 0.9 });

    this.states.forEach((def, idx) => {
      const group = new THREE.Group();
      group.position.set(def.x, def.y, def.z);
      group.rotation.y = def.rotY;

      const frame = new THREE.Mesh(new THREE.BoxGeometry(def.w + 0.07, def.h + 0.07, 0.05), frameMat);
      frame.castShadow = true;
      frame.userData.artId = def.id;
      group.add(frame);

      const backing = new THREE.Mesh(new THREE.PlaneGeometry(def.w + 0.03, def.h + 0.03), matWhite);
      backing.position.z = 0.0255;
      group.add(backing);

      const tex = def.img
        ? def.media === "video"
          ? this.makeVideoTexture(def.id, def.img)
          : this.loadTexture(def.img)
        : makePlaceholderTexture(def.num, def.w, def.h, def.hue, this.displayTitle(def));
      const imgMat = new THREE.MeshStandardMaterial({ map: tex, roughness: 0.85, metalness: 0, envMapIntensity: 0.35 });
      const img = new THREE.Mesh(new THREE.PlaneGeometry(def.w, def.h), imgMat);
      img.position.z = 0.027;
      img.userData.artId = def.id;
      group.add(img);

      const labelTex = makeLabelTexture(def.num, this.displayTitle(def));
      const labelMat = new THREE.MeshBasicMaterial({ map: labelTex });
      const label = new THREE.Mesh(new THREE.PlaneGeometry(0.32, 0.12), labelMat);
      label.position.set(def.w / 2 + 0.27, -0.18, 0.012);
      label.userData.artId = def.id;
      group.add(label);

      this.scene.add(group);
      this.hitMeshes.push(frame, img, label);

      const normal = new THREE.Vector3(Math.sin(def.rotY), 0, Math.cos(def.rotY));
      this.artGroups.set(def.id, {
        group, imgMat, labelMat, def,
        center: new THREE.Vector3(def.x, def.y, def.z),
        normal,
      });

      // accent spotlight per artwork (fewer on mobile for performance)
      if (!this.isMobile || idx % 3 === 0) {
        const spot = new THREE.SpotLight(0xfff1d8, 26, 9, 0.5, 0.75, 1.8);
        spot.position.set(def.x + normal.x * 0.95, 3.85, def.z + normal.z * 0.95);
        spot.target.position.set(def.x, def.y, def.z);
        this.scene.add(spot, spot.target);
      }
    });
  }

  private displayTitle(d: ArtworkState) {
    return d.customTitle || d.title;
  }

  private loadTexture(url: string): THREE.Texture {
    const tex = this.loader.load(url, (t) => {
      t.colorSpace = THREE.SRGBColorSpace;
      t.anisotropy = 8;
    });
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 8;
    return tex;
  }

  private makeVideoTexture(id: string, url: string): THREE.VideoTexture {
    this.stopVideo(id);
    const v = document.createElement("video");
    v.src = url;
    v.muted = true;
    v.loop = true;
    v.playsInline = true;
    v.autoplay = true;
    v.crossOrigin = "anonymous";
    v.play().catch(() => { /* стартует после первого касания */ });
    this.videos.set(id, v);
    const tex = new THREE.VideoTexture(v);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 4;
    return tex;
  }

  private stopVideo(id: string) {
    const v = this.videos.get(id);
    if (v) {
      v.pause();
      v.removeAttribute("src");
      v.load();
      this.videos.delete(id);
    }
  }

  private buildNodes() {
    for (const n of NODES) {
      const ringMat = new THREE.MeshBasicMaterial({ color: 0xc9a86a, transparent: true, opacity: 0.9, side: THREE.DoubleSide });
      const ring = new THREE.Mesh(new THREE.RingGeometry(0.3, 0.38, 40), ringMat);
      ring.rotation.x = -Math.PI / 2;
      ring.position.set(n.x, 0.012, n.z);
      this.scene.add(ring);
      const dot = new THREE.Mesh(new THREE.CircleGeometry(0.07, 20), new THREE.MeshBasicMaterial({ color: 0xc9a86a }));
      dot.rotation.x = -Math.PI / 2;
      dot.position.set(n.x, 0.013, n.z);
      this.scene.add(dot);
      this.nodeMarkers.push({ node: n, ring, pos: new THREE.Vector3(n.x, 0.1, n.z) });
    }
  }

  private buildColliders() {
    for (const p of PARTITIONS) {
      this.colliders.push({ x: p.x, z: p.z, hx: p.w / 2, hz: ROOM.PART_T / 2, rot: p.rotY });
    }
    for (const b of BENCHES) {
      this.colliders.push({ x: b.x, z: b.z, hx: b.w / 2, hz: b.d / 2, rot: b.rotY });
    }
  }

  /* ================= EVENTS ================= */
  private onPointerDown = (e: PointerEvent) => {
    // мягкий пинок автоплею видео (требование мобильных браузеров)
    this.videos.forEach((v) => { if (v.paused) v.play().catch(() => {}); });
    this.dragging = true;
    this.lastPX = e.clientX; this.lastPY = e.clientY;
    this.downX = e.clientX; this.downY = e.clientY; this.downT = performance.now();
    this.lastInteract = performance.now();
    this.cancelTweens("node");
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
  };
  private onPointerMove = (e: PointerEvent) => {
    if (!this.dragging) return;
    const dx = e.clientX - this.lastPX;
    const dy = e.clientY - this.lastPY;
    this.lastPX = e.clientX; this.lastPY = e.clientY;
    const s = this.isMobile ? 0.0044 : 0.0032;
    this.tYaw -= dx * s;
    this.tPitch = THREE.MathUtils.clamp(this.tPitch - dy * s, -1.15, 1.15);
    this.lastInteract = performance.now();
  };
  private onPointerUp = (e: PointerEvent) => {
    this.dragging = false;
    const moved = Math.hypot(e.clientX - this.downX, e.clientY - this.downY);
    const dt = performance.now() - this.downT;
    if (moved < 9 && dt < 600) this.handleClick(e.clientX, e.clientY);
  };
  private onWheel = (e: WheelEvent) => {
    e.preventDefault();
    if (this.focusedId) return;
    const step = THREE.MathUtils.clamp(-e.deltaY * 0.0022, -0.35, 0.35);
    const fx = -Math.sin(this.yaw), fz = -Math.cos(this.yaw);
    const nx = this.camera.position.x + fx * step * 3;
    const nz = this.camera.position.z + fz * step * 3;
    const r = this.resolveCollision(nx, nz);
    this.camera.position.x = r.x; this.camera.position.z = r.z;
    this.lastInteract = performance.now();
  };
  private onKeyDown = (e: KeyboardEvent) => {
    if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Space"].includes(e.code)) e.preventDefault();
    if (e.code === "Escape") { this.unfocus(); return; }
    if (e.code === "KeyF") { this.focusNearest(); return; }
    this.keys.add(e.code);
    this.cancelTweens("node");
    this.lastInteract = performance.now();
  };
  private onKeyUp = (e: KeyboardEvent) => { this.keys.delete(e.code); };
  private onOrient = (e: DeviceOrientationEvent) => {
    if (!this.gyro || e.alpha == null || e.beta == null) return;
    if (!this.gyroBase) {
      this.gyroBase = { a: e.alpha, b: e.beta };
      this.gyroYaw0 = this.tYaw;
      this.gyroPitch0 = this.tPitch;
      return;
    }
    const dA = normAngle(((e.alpha - this.gyroBase.a) * Math.PI) / 180);
    const dB = ((e.beta - this.gyroBase.b) * Math.PI) / 180;
    this.tYaw = this.gyroYaw0 - dA;
    this.tPitch = THREE.MathUtils.clamp(this.gyroPitch0 - dB * 0.9, -1.15, 1.15);
  };
  private onResize = () => {
    const w = this.container.clientWidth, h = this.container.clientHeight;
    if (!w || !h) return;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  };

  private bindEvents() {
    const el = this.renderer.domElement;
    el.addEventListener("pointerdown", this.onPointerDown);
    window.addEventListener("pointermove", this.onPointerMove);
    window.addEventListener("pointerup", this.onPointerUp);
    el.addEventListener("wheel", this.onWheel, { passive: false });
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("deviceorientation", this.onOrient);
    this.resizeObs = new ResizeObserver(this.onResize);
    this.resizeObs.observe(this.container);
  }

  private handleClick(px: number, py: number) {
    const rect = this.renderer.domElement.getBoundingClientRect();
    const ndc = new THREE.Vector2(((px - rect.left) / rect.width) * 2 - 1, -((py - rect.top) / rect.height) * 2 + 1);
    this.raycaster.setFromCamera(ndc, this.camera);
    const hits = this.raycaster.intersectObjects(this.hitMeshes, false);
    if (hits.length) {
      const id = hits[0].object.userData.artId as string;
      if (this.focusedId === id) this.unfocus();
      else this.focusArtwork(id);
    }
  }

  /* ================= COLLISION ================= */
  private resolveCollision(px: number, pz: number) {
    const R = 0.32;
    const minX = -ROOM.W / 2 + 0.45, maxX = ROOM.W / 2 - 0.45;
    const minZ = -ROOM.L / 2 + 0.45, maxZ = ROOM.L / 2 - 0.45;
    px = THREE.MathUtils.clamp(px, minX, maxX);
    pz = THREE.MathUtils.clamp(pz, minZ, maxZ);
    for (let iter = 0; iter < 2; iter++) {
      for (const c of this.colliders) {
        const dx = px - c.x, dz = pz - c.z;
        const cos = Math.cos(-c.rot), sin = Math.sin(-c.rot);
        const lx = cos * dx - sin * dz;
        const lz = sin * dx + cos * dz;
        const qx = THREE.MathUtils.clamp(lx, -c.hx, c.hx);
        const qz = THREE.MathUtils.clamp(lz, -c.hz, c.hz);
        let ox = lx - qx, oz = lz - qz;
        const d2 = ox * ox + oz * oz;
        if (d2 > R * R) continue;
        if (d2 > 1e-8) {
          const d = Math.sqrt(d2);
          const push = (R - d) / d;
          ox *= push; oz *= push;
        } else {
          // центр внутри — вытолкнуть по минимальной оси
          const pxIn = c.hx - Math.abs(lx), pzIn = c.hz - Math.abs(lz);
          if (pxIn < pzIn) { ox = (lx >= 0 ? 1 : -1) * (pxIn + R); oz = 0; }
          else { ox = 0; oz = (lz >= 0 ? 1 : -1) * (pzIn + R); }
        }
        const cos2 = Math.cos(c.rot), sin2 = Math.sin(c.rot);
        px += cos2 * ox - sin2 * oz;
        pz += sin2 * ox + cos2 * oz;
      }
    }
    return { x: THREE.MathUtils.clamp(px, minX, maxX), z: THREE.MathUtils.clamp(pz, minZ, maxZ) };
  }

  /* ================= TWEEN ================= */
  private addTween(t: Tween) { this.tweens.push(t); }
  private cancelTweens(tag: string) { this.tweens = this.tweens.filter((t) => t.tag !== tag); }

  /* ================= ACTIONS ================= */
  focusArtwork(id: string) {
    const rec = this.artGroups.get(id);
    if (!rec) return;
    this.cancelTweens("node");
    this.cancelTweens("focus");
    if (!this.focusedId) {
      this.savedView = { x: this.camera.position.x, z: this.camera.position.z, yaw: this.tYaw, pitch: this.tPitch };
    }
    const { center, normal, def } = rec;
    const dist = THREE.MathUtils.clamp(Math.max(def.w, def.h) * 1.35 + 0.6, 1.4, 2.7);
    const tx = center.x + normal.x * dist;
    const tz = center.z + normal.z * dist;
    const ty = center.y;
    const yawT = nearestAngle(this.tYaw, Math.atan2(normal.x, normal.z));
    const pitchT = 0;
    const sx = this.camera.position.x, sz = this.camera.position.z, sy = this.camera.position.y;
    const syaw = this.tYaw, spitch = this.tPitch;
    // резкий наезд — 0.65 c
    this.addTween({
      t: 0, dur: 0.65, tag: "focus", ease: easeOutExpo,
      update: (k) => {
        this.camera.position.x = sx + (tx - sx) * k;
        this.camera.position.z = sz + (tz - sz) * k;
        this.camera.position.y = sy + (ty - sy) * k;
        this.tYaw = syaw + (yawT - syaw) * k;
        this.tPitch = spitch + (pitchT - spitch) * k;
      },
      done: () => {
        this.focusedId = id;
        this.cb.onFocus(id);
      },
    });
    // сразу подсветить
    this.cb.onFocus(id);
    this.focusedId = id;
  }

  unfocus() {
    if (!this.focusedId || !this.savedView) {
      if (this.focusedId) { this.focusedId = null; this.cb.onFocus(null); }
      return;
    }
    this.cancelTweens("focus");
    const s = this.savedView;
    const sx = this.camera.position.x, sz = this.camera.position.z, sy = this.camera.position.y;
    const syaw = this.tYaw, spitch = this.tPitch;
    const yawT = nearestAngle(syaw, s.yaw);
    // резкий возврат
    this.addTween({
      t: 0, dur: 0.6, tag: "focus", ease: easeOutExpo,
      update: (k) => {
        this.camera.position.x = sx + (s.x - sx) * k;
        this.camera.position.z = sz + (s.z - sz) * k;
        this.camera.position.y = sy + (ROOM.EYE - sy) * k;
        this.tYaw = syaw + (yawT - syaw) * k;
        this.tPitch = spitch + (s.pitch - spitch) * k;
      },
      done: () => { this.savedView = null; },
    });
    this.focusedId = null;
    this.cb.onFocus(null);
  }

  focusNearest() {
    if (this.focusedId) { this.unfocus(); return; }
    let best: string | null = null; let bestD = 1e9;
    const p = this.camera.position;
    for (const [id, rec] of this.artGroups) {
      const toArt = this.tmpV.copy(rec.center).sub(p);
      const d = toArt.length();
      toArt.normalize();
      const facing = toArt.dot(rec.normal);
      // камера должна быть перед работой
      const inFront = this.tmpV.copy(p).sub(rec.center).dot(rec.normal) > 0.2;
      if (!inFront || facing < -0.9) continue;
      const fwd = new THREE.Vector3(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
      const align = new THREE.Vector3(rec.center.x - p.x, 0, rec.center.z - p.z).normalize().dot(fwd);
      const score = d - align * 3;
      if (score < bestD) { bestD = score; best = id; }
    }
    if (best) this.focusArtwork(best);
  }

  focusStep(dir: 1 | -1) {
    const ids = this.states.map((s) => s.id);
    if (!this.focusedId) { this.focusArtwork(ids[0]); return; }
    const i = ids.indexOf(this.focusedId);
    const n = ids[(i + dir + ids.length) % ids.length];
    this.focusArtwork(n);
  }

  goToNode(id: string) {
    const n = NODES.find((x) => x.id === id);
    if (!n) return;
    if (this.focusedId) { this.focusedId = null; this.cb.onFocus(null); this.savedView = null; }
    this.cancelTweens("node");
    this.cancelTweens("focus");
    const sx = this.camera.position.x, sz = this.camera.position.z;
    const syaw = this.tYaw, spitch = this.tPitch;
    const yawT = nearestAngle(syaw, n.yaw);
    this.addTween({
      t: 0, dur: 1.15, tag: "node", ease: easeInOut,
      update: (k) => {
        this.camera.position.x = sx + (n.x - sx) * k;
        this.camera.position.z = sz + (n.z - sz) * k;
        this.camera.position.y = ROOM.EYE + Math.sin(k * Math.PI) * 0.06;
        this.tYaw = syaw + (yawT - syaw) * k;
        this.tPitch = spitch + (0 - spitch) * k;
      },
    });
    this.lastInteract = performance.now();
  }

  setAutoRotate(v: boolean) { this.autoRotate = v; }
  isAutoRotate() { return this.autoRotate; }
  isFocused() { return this.focusedId; }
  setPaused(v: boolean) {
    this.paused = v;
    if (!v) { this.clock.getDelta(); }
  }
  setJoystick(x: number, y: number) { this.joy.x = x; this.joy.y = y; }

  async setGyro(v: boolean): Promise<boolean> {
    if (v) {
      try {
        const DOE = DeviceOrientationEvent as unknown as { requestPermission?: () => Promise<string> };
        if (DOE.requestPermission) {
          const res = await DOE.requestPermission();
          if (res !== "granted") return false;
        }
      } catch { return false; }
      this.gyroBase = null;
      this.gyro = true;
      return true;
    }
    this.gyro = false;
    this.gyroBase = null;
    return true;
  }
  isGyro() { return this.gyro; }

  setArtworkMedia(id: string, url: string | null, title?: string, kind?: "image" | "video") {
    const rec = this.artGroups.get(id);
    if (!rec) return;
    const st = this.states.find((s) => s.id === id);
    if (st) {
      st.img = url ?? st.defaultImg;
      if (title !== undefined) st.customTitle = title;
      if (kind) st.media = kind;
    }
    const def = rec.def;
    const old = rec.imgMat.map;
    this.stopVideo(id);
    const tex = url
      ? kind === "video"
        ? this.makeVideoTexture(id, url)
        : this.loadTexture(url)
      : def.defaultImg && st?.img === def.defaultImg
        ? this.loadTexture(def.defaultImg)
        : makePlaceholderTexture(def.num, def.w, def.h, def.hue, title || this.displayTitle(def));
    rec.imgMat.map = tex;
    rec.imgMat.needsUpdate = true;
    old?.dispose();
    // label
    const lt = makeLabelTexture(def.num, title || this.displayTitle(def));
    rec.labelMat.map?.dispose();
    rec.labelMat.map = lt;
    rec.labelMat.needsUpdate = true;
  }

  /* ================= LOOP ================= */
  private loop = () => {
    this.raf = requestAnimationFrame(this.loop);
    if (this.paused) return;
    const dt = Math.min(this.clock.getDelta(), 0.05);
    const now = performance.now();

    // tweens
    for (let i = this.tweens.length - 1; i >= 0; i--) {
      const tw = this.tweens[i];
      tw.t += dt;
      const k = tw.ease(Math.min(1, tw.t / tw.dur));
      tw.update(k);
      if (tw.t >= tw.dur) { this.tweens.splice(i, 1); tw.done?.(); }
    }
    const tweening = this.tweens.length > 0;

    // keyboard turn (arrows) — always allowed when not focused
    if (!this.focusedId && !tweening) {
      const turn = 1.9 * dt;
      if (this.keys.has("ArrowLeft")) this.tYaw += turn;
      if (this.keys.has("ArrowRight")) this.tYaw -= turn;
    }

    // movement
    if (!this.focusedId && !tweening) {
      let fwd = 0, strafe = 0;
      if (this.keys.has("KeyW") || this.keys.has("ArrowUp")) fwd += 1;
      if (this.keys.has("KeyS") || this.keys.has("ArrowDown")) fwd -= 1;
      if (this.keys.has("KeyA")) strafe -= 1;
      if (this.keys.has("KeyD")) strafe += 1;
      fwd += -this.joy.y;
      strafe += this.joy.x;
      const len = Math.hypot(fwd, strafe);
      if (len > 0.01) {
        const run = this.keys.has("ShiftLeft") || this.keys.has("ShiftRight");
        const speed = (run ? 4.4 : 2.3) * Math.min(1, len);
        const fx = -Math.sin(this.yaw), fz = -Math.cos(this.yaw);
        const rx = Math.cos(this.yaw), rz = -Math.sin(this.yaw);
        const nx = this.camera.position.x + (fx * fwd + rx * strafe) * speed * dt;
        const nz = this.camera.position.z + (fz * fwd + rz * strafe) * speed * dt;
        const r = this.resolveCollision(nx, nz);
        this.camera.position.x = r.x; this.camera.position.z = r.z;
        this.bobPhase += dt * speed * 3.4;
        this.camera.position.y = ROOM.EYE + Math.sin(this.bobPhase) * 0.022;
        this.lastInteract = now;
      } else {
        this.camera.position.y += (ROOM.EYE - this.camera.position.y) * Math.min(1, dt * 6);
      }
    }

    // panorama auto-rotate
    if (this.autoRotate && !this.focusedId && !this.dragging && now - this.lastInteract > 2500) {
      this.tYaw += dt * 0.22;
    }

    // smooth follow (gyro) or direct
    if (this.gyro) {
      this.yaw += normAngle(this.tYaw - this.yaw) * Math.min(1, dt * 7);
      this.pitch += (this.tPitch - this.pitch) * Math.min(1, dt * 7);
    } else {
      this.yaw = this.tYaw;
      this.pitch = this.tPitch;
    }
    this.camera.rotation.y = this.yaw;
    this.camera.rotation.x = this.pitch;

    // node rings pulse
    const pulse = 1 + Math.sin(now * 0.0032) * 0.12;
    for (const m of this.nodeMarkers) {
      m.ring.scale.set(pulse, pulse, 1);
      (m.ring.material as THREE.MeshBasicMaterial).opacity = 0.65 + Math.sin(now * 0.0032) * 0.25;
    }

    this.updateHotspots();
    this.renderer.render(this.scene, this.camera);

    this.moveTick += dt;
    if (this.moveTick > 0.08) {
      this.moveTick = 0;
      this.cb.onMove(this.camera.position.x, this.camera.position.z, this.yaw, this.pitch);
    }
  };

  private updateHotspots() {
    const w = this.container.clientWidth, h = this.container.clientHeight;
    const arts: Hotspot[] = [];
    const now = performance.now();

    // occlusion refresh (throttled)
    if (now - this.occTick > 160) {
      this.occTick = now;
      for (const [id, rec] of this.artGroups) {
        const dir = this.tmpV.copy(rec.center).sub(this.camera.position);
        const dist = dir.length();
        dir.normalize();
        this.raycaster.set(this.camera.position, dir);
        this.raycaster.far = dist - 0.25;
        const hits = this.raycaster.intersectObjects(this.occluders, false);
        this.occlusionCache.set(id, hits.length > 0);
      }
    }

    const camDir = new THREE.Vector3();
    this.camera.getWorldDirection(camDir);

    for (const [id, rec] of this.artGroups) {
      const toC = this.tmpV.copy(rec.center).sub(this.camera.position);
      const dist = toC.length();
      const inFront = toC.normalize().dot(camDir) > 0.12;
      const facing = this.camera.position.clone().sub(rec.center).dot(rec.normal) > 0.15;
      const p = rec.center.clone().project(this.camera);
      const onScreen = p.z < 1 && p.x > -1.15 && p.x < 1.15 && p.y > -1.15 && p.y < 1.15;
      const occluded = this.occlusionCache.get(id) ?? false;
      const visible = inFront && facing && onScreen && !occluded && !this.focusedId && dist < 16;
      arts.push({ id, sx: (p.x * 0.5 + 0.5) * w, sy: (-p.y * 0.5 + 0.5) * h, visible, dist });
    }

    const nodes: Hotspot[] = [];
    for (const m of this.nodeMarkers) {
      const d = Math.hypot(m.pos.x - this.camera.position.x, m.pos.z - this.camera.position.z);
      const p = m.pos.clone().setY(0.35).project(this.camera);
      const toN = new THREE.Vector3(m.pos.x - this.camera.position.x, 0, m.pos.z - this.camera.position.z).normalize();
      const inFront = toN.dot(new THREE.Vector3(camDir.x, 0, camDir.z).normalize()) > -0.2;
      const onScreen = p.z < 1 && p.x > -1.1 && p.x < 1.1 && p.y > -1.1 && p.y < 1.1;
      nodes.push({
        id: m.node.id,
        sx: (p.x * 0.5 + 0.5) * w,
        sy: (-p.y * 0.5 + 0.5) * h,
        visible: !this.focusedId && d > 0.9 && d < 20 && onScreen && inFront,
        dist: d,
      });
    }
    this.cb.onHotspots(arts, nodes);
  }

  dispose() {
    cancelAnimationFrame(this.raf);
    this.videos.forEach((v) => { v.pause(); v.removeAttribute("src"); v.load(); });
    this.videos.clear();
    const el = this.renderer?.domElement;
    if (el) {
      el.removeEventListener("pointerdown", this.onPointerDown);
      el.removeEventListener("wheel", this.onWheel);
    }
    window.removeEventListener("pointermove", this.onPointerMove);
    window.removeEventListener("pointerup", this.onPointerUp);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("deviceorientation", this.onOrient);
    this.resizeObs?.disconnect();
    this.scene?.traverse((o) => {
      const mesh = o as THREE.Mesh;
      if (mesh.geometry) mesh.geometry.dispose();
      const mat = (mesh as THREE.Mesh).material as THREE.Material | THREE.Material[] | undefined;
      if (Array.isArray(mat)) mat.forEach((m) => { const mm = m as THREE.MeshStandardMaterial; mm.map?.dispose(); m.dispose(); });
      else if (mat) { const mm = mat as THREE.MeshStandardMaterial; mm.map?.dispose(); mat.dispose(); }
    });
    this.renderer?.dispose();
    if (el?.parentElement === this.container) this.container.removeChild(el);
  }
}
