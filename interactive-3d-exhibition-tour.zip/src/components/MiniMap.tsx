import { memo } from "react";
import { ROOM, PARTITIONS, BENCHES, NODES, ARTWORKS } from "../data/gallery";

interface Props {
  px: number; pz: number; yaw: number;
  onNode: (id: string) => void;
}

// top-down: x -> right, z(-13 top/north) -> down? North at top.
const W = 8, L = 26;
const VW = 120, VH = 120 * (L / W); // 390

function X(x: number) { return ((x + W / 2) / W) * VW; }
function Z(z: number) { return ((z + L / 2) / L) * VH; }

function MiniMap({ px, pz, yaw, onNode }: Props) {
  const cx = X(px), cy = Z(pz);
  const dirLen = 26;
  const dx = Math.sin(yaw) * -1; // forward x = -sin(yaw)
  const dz = Math.cos(yaw) * -1; // forward z = -cos(yaw)
  return (
    <svg viewBox={`-14 -14 ${VW + 28} ${VH + 28}`} className="h-auto w-full">
      {/* floor */}
      <rect x={0} y={0} width={VW} height={VH} rx={3} fill="rgba(245,242,236,0.07)" stroke="rgba(255,255,255,0.4)" strokeWidth={1.5} />
      {/* wood hint lines */}
      {Array.from({ length: 9 }).map((_, i) => (
        <line key={i} x1={(VW / 8) * i} y1={0} x2={(VW / 8) * i} y2={VH} stroke="rgba(255,255,255,0.05)" strokeWidth={1} />
      ))}
      {/* benches */}
      {BENCHES.map((b, i) => {
        const w = (b.w / W) * VW, d = (b.d / L) * VH;
        return (
          <rect key={i} x={X(b.x) - w / 2} y={Z(b.z) - d / 2} width={w} height={d}
            fill="rgba(255,255,255,0.35)" rx={1}
            transform={b.rotY ? `rotate(90 ${X(b.x)} ${Z(b.z)})` : undefined} />
        );
      })}
      {/* partitions */}
      {PARTITIONS.map((p) => {
        const dx = Math.cos(p.rotY), dz = -Math.sin(p.rotY);
        return (
          <line key={p.id}
            x1={X(p.x - (dx * p.w) / 2)} y1={Z(p.z - (dz * p.w) / 2)}
            x2={X(p.x + (dx * p.w) / 2)} y2={Z(p.z + (dz * p.w) / 2)}
            stroke="#f5f2ec" strokeWidth={3.4} strokeLinecap="round" />
        );
      })}
      {/* artworks ticks */}
      {ARTWORKS.map((a) => (
        <circle key={a.id} cx={X(a.x)} cy={Z(a.z)} r={1.6} fill="#c9a86a" opacity={0.9} />
      ))}
      {/* nodes */}
      {NODES.map((n) => (
        <g key={n.id} onClick={() => onNode(n.id)} className="cursor-pointer">
          <circle cx={X(n.x)} cy={Z(n.z)} r={7} fill="transparent" />
          <circle cx={X(n.x)} cy={Z(n.z)} r={3.4} fill="rgba(201,168,106,0.25)" stroke="#c9a86a" strokeWidth={1.2} />
          <text x={X(n.x)} y={Z(n.z) - 5.5} textAnchor="middle" fontSize={6.5} fill="#f5f2ec" fontFamily="JetBrains Mono, monospace">{n.id}</text>
        </g>
      ))}
      {/* player */}
      <line x1={cx} y1={cy} x2={cx + dx * dirLen} y2={cy + dz * dirLen} stroke="#fff" strokeWidth={2} strokeLinecap="round" opacity={0.9} />
      <circle cx={cx} cy={cy} r={4.6} fill="#fff" stroke="#0b0b0d" strokeWidth={1.5} />
      <circle cx={cx} cy={cy} r={8.5} fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth={1} className="anim-beacon" style={{ transformOrigin: `${cx}px ${cy}px` }} />
      {/* north */}
      <text x={VW / 2} y={-4} textAnchor="middle" fontSize={8} fill="rgba(255,255,255,0.6)" fontFamily="JetBrains Mono, monospace">СЕВЕР · N</text>
      <text x={VW / 2} y={VH + 11} textAnchor="middle" fontSize={8} fill="rgba(255,255,255,0.6)" fontFamily="JetBrains Mono, monospace">ВХОД · {ROOM.W}×{ROOM.L} М</text>
    </svg>
  );
}

export default memo(MiniMap);
