import { useEffect, useMemo, useRef, useState } from "react";
import {
  Play, X, ChevronLeft, ChevronRight, Footprints, Expand, RotateCw,
  Compass, Upload, LayoutGrid, Images, Maximize, MapPin, Mouse, Keyboard, Move, Eye, Navigation, Lock,
} from "lucide-react";
import { GalleryEngine, type Hotspot } from "../engine/GalleryEngine";
import { NODES, ROOM, type ArtworkState, type MediaKind } from "../data/gallery";
import { placeholderDataURL, downscaleImage } from "../utils/textures";
import { cacheBlob, idbSet, MAX_VIDEO_BYTES, formatMB } from "../utils/mediaStore";
import MiniMap from "./MiniMap";

interface Props {
  artworks: ArtworkState[];
  onUpload: (id: string, url: string, kind: MediaKind) => void;
  focusedId: string | null;
  setFocusedId: (id: string | null) => void;
  engineRef: React.MutableRefObject<GalleryEngine | null>;
  panoRequest: { nodeId: string; t: number } | null;
  focusRequest: { artId: string; t: number } | null;
  locked: boolean;
  onOpenPlans: () => void;
  onOpenWorks: () => void;
}

export default function TourViewer({ artworks, onUpload, focusedId, setFocusedId, engineRef, panoRequest, focusRequest, locked, onOpenPlans, onOpenWorks }: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const artDotRefs = useRef(new Map<string, HTMLDivElement>());
  const nodeDotRefs = useRef(new Map<string, HTMLDivElement>());
  const fileRef = useRef<HTMLInputElement>(null);
  const joyBaseRef = useRef<HTMLDivElement>(null);
  const joyKnobRef = useRef<HTMLDivElement>(null);
  const uploadTarget = useRef<string | null>(null);
  const joyActive = useRef(false);

  const [loading, setLoading] = useState(true);
  const [intro, setIntro] = useState(true);
  const [help, setHelp] = useState(false);
  const [gyroOn, setGyroOn] = useState(false);
  const [spin, setSpin] = useState(false);
  const [pos, setPos] = useState({ x: 0, z: 11.3, yaw: 0 });
  const [showMap, setShowMap] = useState(false);
  const [isTouch] = useState(() => window.matchMedia("(pointer: coarse)").matches);

  const focused = useMemo(() => artworks.find((a) => a.id === focusedId) ?? null, [artworks, focusedId]);
  const focusedURL = useMemo(() => {
    if (!focused) return null;
    return focused.img ?? placeholderDataURL(focused.num, focused.w, focused.h, focused.hue, focused.customTitle || focused.title);
  }, [focused]);

  /* ---------- engine lifecycle ---------- */
  useEffect(() => {
    if (!containerRef.current) return;
    const engine = new GalleryEngine(
      containerRef.current,
      artworks,
      {
        onHotspots: (arts: Hotspot[], nodes: Hotspot[]) => {
          for (const h of arts) {
            const el = artDotRefs.current.get(h.id);
            if (!el) continue;
            el.style.transform = `translate(${h.sx.toFixed(1)}px, ${h.sy.toFixed(1)}px) translate(-50%,-50%)`;
            el.style.opacity = h.visible ? "1" : "0";
            el.style.pointerEvents = h.visible ? "auto" : "none";
            const s = h.dist < 3 ? 1.15 : h.dist > 9 ? 0.8 : 1;
            el.style.setProperty("--hs", String(s));
            (el.firstElementChild as HTMLElement | null)?.style.setProperty("transform", `scale(${s})`);
          }
          for (const h of nodes) {
            const el = nodeDotRefs.current.get(h.id);
            if (!el) continue;
            el.style.transform = `translate(${h.sx.toFixed(1)}px, ${h.sy.toFixed(1)}px) translate(-50%,-140%)`;
            el.style.opacity = h.visible ? "1" : "0";
            el.style.pointerEvents = h.visible ? "auto" : "none";
          }
        },
        onMove: (x, z, yaw) => setPos({ x, z, yaw }),
        onFocus: (id) => setFocusedId(id),
        onReady: () => setLoading(false),
      }
    );
    engine.init();
    engineRef.current = engine;
    return () => {
      engine.dispose();
      engineRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ---------- panorama requests from Plans ---------- */
  useEffect(() => {
    if (!panoRequest || !engineRef.current) return;
    setIntro(false);
    engineRef.current.goToNode(panoRequest.nodeId);
    engineRef.current.setAutoRotate(true);
    setSpin(true);
  }, [panoRequest, engineRef]);

  /* ---------- focus requests from Plans / Works ---------- */
  useEffect(() => {
    if (!focusRequest || !engineRef.current) return;
    setIntro(false);
    engineRef.current.focusArtwork(focusRequest.artId);
  }, [focusRequest, engineRef]);

  /* ---------- joystick ---------- */
  useEffect(() => {
    const base = joyBaseRef.current;
    const knob = joyKnobRef.current;
    if (!base || !knob || !isTouch) return;
    const R = 38;
    const setKnob = (dx: number, dy: number) => {
      knob.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
    };
    const onDown = (e: PointerEvent) => {
      joyActive.current = true;
      base.setPointerCapture(e.pointerId);
      onMove(e);
    };
    const onMove = (e: PointerEvent) => {
      if (!joyActive.current) return;
      const r = base.getBoundingClientRect();
      let dx = e.clientX - (r.left + r.width / 2);
      let dy = e.clientY - (r.top + r.height / 2);
      const len = Math.hypot(dx, dy);
      if (len > R) { dx = (dx / len) * R; dy = (dy / len) * R; }
      setKnob(dx, dy);
      engineRef.current?.setJoystick(dx / R, dy / R);
    };
    const onUp = () => {
      joyActive.current = false;
      setKnob(0, 0);
      engineRef.current?.setJoystick(0, 0);
    };
    base.addEventListener("pointerdown", onDown);
    base.addEventListener("pointermove", onMove);
    base.addEventListener("pointerup", onUp);
    base.addEventListener("pointercancel", onUp);
    return () => {
      base.removeEventListener("pointerdown", onDown);
      base.removeEventListener("pointermove", onMove);
      base.removeEventListener("pointerup", onUp);
      base.removeEventListener("pointercancel", onUp);
    };
  }, [isTouch, intro, engineRef]);

  const toggleSpin = () => {
    const v = !spin;
    setSpin(v);
    engineRef.current?.setAutoRotate(v);
  };

  const toggleGyro = async () => {
    if (!engineRef.current) return;
    if (gyroOn) {
      await engineRef.current.setGyro(false);
      setGyroOn(false);
    } else {
      const ok = await engineRef.current.setGyro(true);
      setGyroOn(ok);
      if (!ok) alert("Гироскоп недоступен на этом устройстве или доступ запрещён.");
    }
  };

  const toggleFs = () => {
    if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
    else document.documentElement.requestFullscreen().catch(() => {});
  };

  const pickFile = (id: string) => {
    uploadTarget.current = id;
    fileRef.current?.click();
  };

  const onFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    e.target.value = "";
    if (!f || !uploadTarget.current) return;
    const id = uploadTarget.current;
    if (f.type.startsWith("video/")) {
      if (f.size > MAX_VIDEO_BYTES) {
        alert(`Видео слишком большое (${formatMB(f.size)}). Максимум — ${formatMB(MAX_VIDEO_BYTES)}.`);
        return;
      }
      const url = cacheBlob(id, f);
      await idbSet(id, f);
      onUpload(id, url, "video");
      return;
    }
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const small = await downscaleImage(reader.result as string, 1600, 0.86);
        onUpload(id, small, "image");
      } catch { alert("Не удалось прочитать изображение"); }
    };
    reader.readAsDataURL(f);
  };

  const eng = () => engineRef.current;

  return (
    <div className="relative h-full w-full overflow-hidden bg-[#0b0b0d]">
      {/* 3D canvas */}
      <div ref={containerRef} className="absolute inset-0" />

      {/* cinematic overlays */}
      <div className="tour-vignette absolute inset-0 z-10" />
      <div className="tour-grain absolute inset-0 z-10" />

      {/* hotspot layers (positions updated imperatively @60fps) */}
      <div className="absolute inset-0 z-20 overflow-hidden" style={{ pointerEvents: "none" }}>
        {artworks.map((a) => (
          <div
            key={a.id}
            ref={(el) => { if (el) artDotRefs.current.set(a.id, el); else artDotRefs.current.delete(a.id); }}
            className="hotspot-art"
            style={{ opacity: 0 }}
            onClick={(e) => { e.stopPropagation(); eng()?.focusArtwork(a.id); }}
          >
            <div className="ring"><span className="num">{a.num}</span></div>
          </div>
        ))}
        {NODES.map((n) => (
          <div
            key={n.id}
            ref={(el) => { if (el) nodeDotRefs.current.set(n.id, el); else nodeDotRefs.current.delete(n.id); }}
            className="hotspot-node"
            style={{ opacity: 0 }}
            onClick={(e) => { e.stopPropagation(); eng()?.goToNode(n.id); }}
          >
            <div className="pill">
              <span className="dot"><Footprints size={12} /></span>
              {n.name}
            </div>
          </div>
        ))}
      </div>

      {/* crosshair */}
      {!focusedId && !intro && (
        <div className="pointer-events-none absolute left-1/2 top-1/2 z-10 -translate-x-1/2 -translate-y-1/2">
          <div className="h-1.5 w-1.5 rounded-full bg-white/80 shadow-[0_0_8px_rgba(255,255,255,0.9)]" />
        </div>
      )}

      {/* ---------- top bar ---------- */}
      <header className="absolute inset-x-0 top-0 z-30 flex items-center justify-between gap-2 bg-gradient-to-b from-black/70 to-transparent px-3 pb-6 pt-3 sm:px-5">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#c9a86a] font-display text-sm font-extrabold text-black">G</div>
          <div className="leading-tight">
            <div className="font-display text-[13px] font-semibold tracking-[0.18em] sm:text-sm">GALEREA · 3D ТУР</div>
            <div className="font-mono2 text-[10px] uppercase tracking-widest text-white/55">выставка плаката · {ROOM.W}×{ROOM.L} м · 360°</div>
          </div>
        </div>
        <div className="flex items-center gap-1.5 sm:gap-2">
          <button onClick={onOpenPlans} className="hidden items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-2 text-xs font-semibold backdrop-blur-md transition hover:bg-white/20 md:flex">
            <LayoutGrid size={14} /> Планы и развёртки
          </button>
          <button onClick={onOpenWorks} className="hidden items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-2 text-xs font-semibold backdrop-blur-md transition hover:bg-white/20 md:flex">
            <Images size={14} /> Работы · 24
          </button>
          <button onClick={toggleSpin} title="Автопанорама 360°" className={`flex h-10 w-10 items-center justify-center rounded-full border backdrop-blur-md transition ${spin ? "border-[#c9a86a] bg-[#c9a86a] text-black" : "border-white/20 bg-white/10 hover:bg-white/20"}`}>
            <RotateCw size={16} className={spin ? "animate-[spin-slow_3s_linear_infinite]" : ""} />
          </button>
          <button onClick={toggleGyro} title="Гироскоп" className={`flex h-10 w-10 items-center justify-center rounded-full border backdrop-blur-md transition ${gyroOn ? "border-[#c9a86a] bg-[#c9a86a] text-black" : "border-white/20 bg-white/10 hover:bg-white/20"}`}>
            <Compass size={16} />
          </button>
          <button onClick={() => setShowMap((v) => !v)} title="Карта" className="flex h-10 w-10 items-center justify-center rounded-full border border-white/20 bg-white/10 backdrop-blur-md transition hover:bg-white/20 lg:hidden">
            <MapPin size={16} />
          </button>
          <button onClick={toggleFs} title="Во весь экран" className="hidden h-10 w-10 items-center justify-center rounded-full border border-white/20 bg-white/10 backdrop-blur-md transition hover:bg-white/20 sm:flex">
            <Maximize size={16} />
          </button>
        </div>
      </header>

      {/* ---------- minimap (desktop) ---------- */}
      <aside className="absolute left-4 top-24 z-30 hidden w-[172px] rounded-2xl border border-white/15 bg-black/55 p-3 backdrop-blur-xl lg:block">
        <div className="mb-2 flex items-center justify-between">
          <span className="font-mono2 text-[10px] uppercase tracking-[0.2em] text-white/60">План зала</span>
          <Navigation size={12} className="text-[#c9a86a]" />
        </div>
        <MiniMap px={pos.x} pz={pos.z} yaw={pos.yaw} onNode={(id) => eng()?.goToNode(id)} />
        <div className="mt-2 border-t border-white/10 pt-2 font-mono2 text-[10px] text-white/50">
          X {pos.x.toFixed(1)} · Z {pos.z.toFixed(1)}
        </div>
      </aside>

      {/* ---------- minimap (mobile popup) ---------- */}
      {showMap && (
        <div className="absolute left-3 top-20 z-30 w-[168px] rounded-2xl border border-white/15 bg-black/70 p-3 backdrop-blur-xl anim-zoom-in lg:hidden">
          <div className="mb-1 flex items-center justify-between">
            <span className="font-mono2 text-[10px] uppercase tracking-[0.2em] text-white/60">План</span>
            <button onClick={() => setShowMap(false)}><X size={14} /></button>
          </div>
          <MiniMap px={pos.x} pz={pos.z} yaw={pos.yaw} onNode={(id) => { eng()?.goToNode(id); setShowMap(false); }} />
        </div>
      )}

      {/* ---------- nodes bottom bar ---------- */}
      {!focusedId && !intro && (
        <nav className="absolute inset-x-0 bottom-0 z-30 bg-gradient-to-t from-black/80 via-black/40 to-transparent px-3 pb-3 pt-8 sm:px-5 sm:pb-4">
          <div className="mx-auto flex max-w-4xl items-center gap-2 overflow-x-auto thin-scroll pb-1">
            {NODES.map((n, i) => (
              <button
                key={n.id}
                onClick={() => eng()?.goToNode(n.id)}
                className="group flex shrink-0 items-center gap-2.5 rounded-full border border-white/15 bg-white/10 py-1.5 pl-1.5 pr-4 backdrop-blur-md transition hover:border-[#c9a86a] hover:bg-white/20"
              >
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-white/15 font-mono2 text-[11px] font-semibold group-hover:bg-[#c9a86a] group-hover:text-black">{i + 1}</span>
                <span className="text-left leading-tight">
                  <span className="block text-xs font-semibold">{n.name}</span>
                  <span className="block font-mono2 text-[10px] text-white/55">{n.sub}</span>
                </span>
              </button>
            ))}
            <button onClick={() => setHelp(true)} className="flex shrink-0 items-center gap-2 rounded-full border border-dashed border-white/25 px-4 py-2.5 text-xs text-white/70 backdrop-blur-md transition hover:bg-white/10">
              <Keyboard size={14} /> Управление
            </button>
          </div>
          {/* mobile tabs */}
          <div className="mx-auto mt-2 flex max-w-4xl gap-2 md:hidden">
            <button onClick={onOpenPlans} className="flex flex-1 items-center justify-center gap-2 rounded-xl border border-white/15 bg-white/10 py-2.5 text-xs font-semibold backdrop-blur-md"><LayoutGrid size={14} /> Планы стен</button>
            <button onClick={onOpenWorks} className="flex flex-1 items-center justify-center gap-2 rounded-xl border border-white/15 bg-white/10 py-2.5 text-xs font-semibold backdrop-blur-md"><Images size={14} /> Мои работы</button>
          </div>
        </nav>
      )}

      {/* ---------- joystick (touch) ---------- */}
      {isTouch && !intro && !focusedId && (
        <div className="absolute bottom-32 left-4 z-30 sm:bottom-28">
          <div ref={joyBaseRef} className="joystick-base">
            <div ref={joyKnobRef} className="joystick-knob" />
          </div>
          <div className="mt-1 text-center font-mono2 text-[9px] uppercase tracking-widest text-white/50">идти</div>
        </div>
      )}
      {isTouch && !intro && !focusedId && (
        <div className="absolute bottom-32 right-4 z-30 flex flex-col gap-2 sm:bottom-28">
          <button onClick={() => eng()?.focusNearest()} className="flex h-12 w-12 items-center justify-center rounded-full border border-white/20 bg-white/10 backdrop-blur-md active:bg-[#c9a86a] active:text-black" title="Ближайшая работа">
            <Eye size={18} />
          </button>
          <button onClick={toggleSpin} className={`flex h-12 w-12 items-center justify-center rounded-full border backdrop-blur-md ${spin ? "border-[#c9a86a] bg-[#c9a86a] text-black" : "border-white/20 bg-white/10"}`} title="Панорама">
            <RotateCw size={18} />
          </button>
        </div>
      )}

      {/* ---------- focused artwork card ---------- */}
      {focused && focusedURL && (
        <div className="absolute inset-x-0 bottom-0 z-40 flex justify-center px-3 pb-3 sm:px-5 sm:pb-5">
          <div className="anim-fade-up flex w-full max-w-4xl flex-col overflow-hidden rounded-2xl border border-white/15 bg-[#101013]/92 shadow-2xl backdrop-blur-2xl sm:flex-row" style={{ maxHeight: "62vh" }}>
            <div className="relative flex items-center justify-center bg-black/60 p-3 sm:w-[46%]">
              {focused.media === "video" && focused.img ? (
                <video src={focused.img} controls autoPlay muted loop playsInline className="max-h-[30vh] w-auto max-w-full rounded-lg object-contain shadow-xl sm:max-h-[46vh]" />
              ) : (
                <img src={focusedURL} alt={focused.title} className="max-h-[30vh] w-auto max-w-full rounded-lg object-contain shadow-xl sm:max-h-[46vh]" />
              )}
              <span className="absolute left-4 top-4 flex gap-1.5">
                <span className="rounded-full bg-black/70 px-2.5 py-1 font-mono2 text-[10px] tracking-widest text-[#c9a86a]">№ {focused.num}</span>
                {focused.media === "video" && focused.img && (
                  <span className="rounded-full bg-[#c9a86a] px-2.5 py-1 font-mono2 text-[10px] font-bold tracking-widest text-black">ВИДЕО</span>
                )}
              </span>
            </div>
            <div className="flex flex-1 flex-col p-4 sm:p-5">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="font-display text-base font-semibold leading-snug sm:text-lg">{focused.customTitle || focused.title}</h3>
                  <p className="mt-1 text-xs text-white/55">{focused.technique}</p>
                </div>
                <button onClick={() => eng()?.unfocus()} className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-white/10 transition hover:bg-white/25" title="Вернуться (Esc)">
                  <X size={16} />
                </button>
              </div>
              <div className="mt-3 grid grid-cols-3 gap-2 font-mono2 text-[10px]">
                <div className="rounded-lg bg-white/5 px-2.5 py-2"><div className="text-white/45">РАЗМЕР</div><div className="text-white/90">{focused.w.toFixed(2)} × {focused.h.toFixed(2)} м</div></div>
                <div className="rounded-lg bg-white/5 px-2.5 py-2"><div className="text-white/45">ЛОКАЦИЯ</div><div className="text-white/90">{focused.zone}</div></div>
                <div className="rounded-lg bg-white/5 px-2.5 py-2"><div className="text-white/45">СВЕТ</div><div className="text-white/90">3000K · SPOT</div></div>
              </div>
              {!focused.img && !locked && (
                <p className="mt-3 rounded-lg border border-dashed border-[#c9a86a]/50 bg-[#c9a86a]/10 px-3 py-2 text-[11px] leading-relaxed text-[#e8d5a8]">
                  {focused.media === "video"
                    ? "Видеофайл не найден в хранилище браузера — вставьте его заново, и он сразу появится на стене в 3D."
                    : "Это место для вашей работы. Нажмите «Заменить», чтобы вставить своё изображение или видео — оно сразу появится на стене в 3D."}
                </p>
              )}
              <div className="mt-auto flex items-center gap-2 pt-4">
                <button onClick={() => eng()?.focusStep(-1)} className="flex h-10 w-10 items-center justify-center rounded-full border border-white/15 bg-white/5 transition hover:bg-white/15"><ChevronLeft size={16} /></button>
                <button onClick={() => eng()?.focusStep(1)} className="flex h-10 w-10 items-center justify-center rounded-full border border-white/15 bg-white/5 transition hover:bg-white/15"><ChevronRight size={16} /></button>
                {locked ? (
                  <div className="flex h-10 flex-1 items-center justify-center gap-2 rounded-full bg-white/5 text-[11px] font-semibold text-white/45">
                    <Lock size={13} /> Защищено от изменений
                  </div>
                ) : (
                  <button onClick={() => pickFile(focused.id)} className="flex h-10 flex-1 items-center justify-center gap-2 rounded-full bg-[#c9a86a] text-xs font-bold text-black transition hover:bg-[#d9b878]">
                    <Upload size={14} /> {focused.img ? "Заменить изображение" : "Вставить свою работу"}
                  </button>
                )}
                <button onClick={() => eng()?.unfocus()} className="hidden h-10 items-center gap-2 rounded-full border border-white/20 px-4 text-xs font-semibold transition hover:bg-white/10 sm:flex">
                  Назад
                </button>
              </div>
              <p className="mt-2 text-center font-mono2 text-[10px] text-white/40">повторный клик по картине · Esc — резкий возврат камеры</p>
            </div>
          </div>
        </div>
      )}

      {/* ---------- help modal ---------- */}
      {help && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm anim-fade-in" onClick={() => setHelp(false)}>
          <div className="w-full max-w-lg rounded-2xl border border-white/15 bg-[#141417] p-6 anim-zoom-in" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <h3 className="font-display text-lg font-semibold">Управление туром</h3>
              <button onClick={() => setHelp(false)} className="flex h-8 w-8 items-center justify-center rounded-full bg-white/10 hover:bg-white/20"><X size={14} /></button>
            </div>
            <div className="mt-4 space-y-3 text-sm">
              {[
                { icon: <Mouse size={16} />, t: "Мышь / палец", d: "Зажмите и ведите — осмотр 360°. Клик по картине — резкий наезд, повторный клик — возврат." },
                { icon: <Keyboard size={16} />, t: "Клавиатура", d: "W A S D или стрелки ↑ ↓ — движение, ← → — поворот. Shift — бег. F — ближайшая работа. Esc — назад." },
                { icon: <Move size={16} />, t: "Колесо мыши", d: "Прокрутка — шаг вперёд / назад." },
                { icon: <Compass size={16} />, t: "Гироскоп", d: "На телефоне включите компас вверху — осмотр движением устройства." },
                { icon: <Footprints size={16} />, t: "Точки перемещения", d: "Золотые пилюли и кольца на полу — мгновенный переход между 6 залами." },
                { icon: <Expand size={16} />, t: "Точки на картинах", d: "Кружки с номерами — фронтальный разворот картины на весь экран в высоком качестве." },
              ].map((r, i) => (
                <div key={i} className="flex gap-3 rounded-xl bg-white/5 p-3">
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#c9a86a]/20 text-[#c9a86a]">{r.icon}</span>
                  <span><b className="text-[13px]">{r.t}.</b> <span className="text-[13px] text-white/65">{r.d}</span></span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ---------- intro ---------- */}
      {intro && !loading && (
        <div className="absolute inset-0 z-50 flex items-center justify-center overflow-y-auto bg-black/72 p-4 backdrop-blur-md">
          <div className="w-full max-w-2xl py-6 text-center anim-fade-up">
            <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-[#c9a86a] font-display text-xl font-extrabold text-black shadow-[0_0_60px_rgba(201,168,106,0.4)]">G</div>
            <p className="font-mono2 text-[11px] uppercase tracking-[0.35em] text-[#c9a86a]">виртуальная выставка · web 3d</p>
            <h1 className="mt-3 font-display text-3xl font-extrabold leading-tight sm:text-5xl">ГРАФИКА<span className="text-outline"> / 360°</span></h1>
            <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-white/65">
              Фотореалистичный тур по галерее {ROOM.W}×{ROOM.L} м: {artworks.length} работы на стенах и пилонах,
              6 точек перемещения, резкий наезд камеры на каждую картину.
            </p>
            <div className="mx-auto mt-5 grid max-w-md grid-cols-3 gap-2 text-[11px]">
              {[
                { icon: <Mouse size={15} />, t: "Мышь — осмотр" },
                { icon: <Keyboard size={15} />, t: "Стрелки — идти" },
                { icon: <Compass size={15} />, t: "Гиро — телефон" },
              ].map((c, i) => (
                <div key={i} className="flex flex-col items-center gap-1.5 rounded-xl border border-white/12 bg-white/5 px-2 py-3 text-white/70">
                  <span className="text-[#c9a86a]">{c.icon}</span>{c.t}
                </div>
              ))}
            </div>
            <button
              onClick={() => { setIntro(false); eng()?.goToNode("N1"); }}
              className="group mx-auto mt-6 flex items-center gap-3 rounded-full bg-[#f5f2ec] px-8 py-4 font-display text-sm font-bold text-black transition hover:bg-[#c9a86a]"
            >
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-black text-white transition group-hover:scale-110"><Play size={14} /></span>
              НАЧАТЬ 3D-ТУР
            </button>
            <div className="mt-4 flex items-center justify-center gap-2">
              <button onClick={onOpenPlans} className="rounded-full border border-white/20 px-5 py-2.5 text-xs font-semibold text-white/80 transition hover:bg-white/10"><span className="mr-1.5 inline-block align-[-2px]"><LayoutGrid size={13} className="inline" /></span>Сначала планы стен</button>
              <button onClick={() => setHelp(true)} className="rounded-full border border-white/20 px-5 py-2.5 text-xs font-semibold text-white/80 transition hover:bg-white/10">Управление</button>
            </div>
          </div>
        </div>
      )}

      {/* ---------- loader ---------- */}
      {loading && (
        <div className="absolute inset-0 z-[60] flex flex-col items-center justify-center bg-[#0b0b0d]">
          <div className="h-12 w-12 animate-[spin-slow_1.2s_linear_infinite] rounded-full border-2 border-white/15 border-t-[#c9a86a]" />
          <p className="mt-5 font-display text-sm tracking-[0.25em]">РЕНДЕР ГАЛЕРЕИ…</p>
          <p className="mt-2 font-mono2 text-[11px] text-white/45">свет · дуб · 24 рамы · 360°</p>
        </div>
      )}

      <input ref={fileRef} type="file" accept="image/*,video/*" className="hidden" onChange={onFile} />
    </div>
  );
}
