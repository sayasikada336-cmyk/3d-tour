import { useMemo, useRef, useState } from "react";
import { X, Upload, RotateCcw, Eye, Download, FileUp, FileDown, Lock, LockOpen } from "lucide-react";
import type { ArtworkState, MediaKind } from "../data/gallery";
import { placeholderDataURL, downscaleImage } from "../utils/textures";
import { hasPin, estimateMediaBytes, BASE_HTML_BYTES } from "../utils/protect";
import { cacheBlob, idbSet, MAX_VIDEO_BYTES, formatMB } from "../utils/mediaStore";

interface Props {
  artworks: ArtworkState[];
  onUpload: (id: string, url: string, kind: MediaKind) => void;
  onReset: (id: string) => void;
  onTitle: (id: string, title: string) => void;
  onShowArt: (id: string) => void;
  onClose: () => void;
  locked: boolean;
  hardLock: boolean;
  saving: boolean;
  onExportJSON: () => Promise<void>;
  onImportJSON: (file: File) => void;
  onSaveFile: () => Promise<void>;
  onSetPin: (pin: string) => Promise<void>;
  onUnlock: (pin: string) => Promise<boolean>;
  onRelock: () => void;
}

export default function ArtworksManager(props: Props) {
  const { artworks, onUpload, onReset, onTitle, onShowArt, onClose } = props;
  const { locked, hardLock, saving } = props;
  const fileRef = useRef<HTMLInputElement>(null);
  const importRef = useRef<HTMLInputElement>(null);
  const target = useRef<string | null>(null);
  const [q, setQ] = useState("");
  const [pinMode, setPinMode] = useState<null | "set" | "unlock">(null);
  const [pin, setPin] = useState("");
  const [pinErr, setPinErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [saved, setSaved] = useState(false);

  const urls = useMemo(() => {
    const m = new Map<string, string>();
    for (const a of artworks) m.set(a.id, a.img ?? placeholderDataURL(a.num, a.w, a.h, a.hue, a.customTitle || a.title));
    return m;
  }, [artworks]);

  const publishSize = useMemo(
    () => formatMB(BASE_HTML_BYTES + Math.floor(estimateMediaBytes(artworks) * 1.37)),
    [artworks]
  );

  const customCount = artworks.filter((a) => (a.img && a.img !== a.defaultImg) || a.media === "video").length;
  const videoCount = artworks.filter((a) => a.media === "video" && a.img).length;
  const list = q ? artworks.filter((a) => `${a.num} ${a.customTitle || a.title} ${a.zone}`.toLowerCase().includes(q.toLowerCase())) : artworks;

  const pick = (id: string) => { target.current = id; fileRef.current?.click(); };
  const onFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    e.target.value = "";
    if (!f || !target.current) return;
    const id = target.current;
    if (f.type.startsWith("video/")) {
      if (f.size > MAX_VIDEO_BYTES) {
        alert(`Видео слишком большое (${formatMB(f.size)}). Максимум — ${formatMB(MAX_VIDEO_BYTES)}.`);
        return;
      }
      const url = cacheBlob(id, f);
      await idbSet(id, f);
      onUpload(id, url, "video");
      return;
    }
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const small = await downscaleImage(reader.result as string, 1600, 0.86);
        onUpload(id, small, "image");
      } catch { alert("Не удалось прочитать изображение"); }
    };
    reader.readAsDataURL(f);
  };

  const onImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    e.target.value = "";
    if (f) props.onImportJSON(f);
  };

  const onLockClick = () => {
    if (hardLock) return;
    if (locked) { setPin(""); setPinErr(""); setPinMode("unlock"); }
    else if (hasPin()) props.onRelock();
    else { setPin(""); setPinErr(""); setPinMode("set"); }
  };

  const submitPin = async () => {
    const v = pin.trim();
    if (pinMode === "set" && v.length < 4) { setPinErr("PIN — минимум 4 символа"); return; }
    if (!v) { setPinErr("Введите PIN"); return; }
    setBusy(true);
    try {
      if (pinMode === "set") {
        await props.onSetPin(v);
        setPinMode(null);
      } else {
        const ok = await props.onUnlock(v);
        if (ok) setPinMode(null);
        else setPinErr("Неверный PIN — попробуйте ещё раз");
      }
    } finally {
      setBusy(false);
      setPin("");
    }
  };

  const onSaveClick = async () => {
    setSaved(false);
    await props.onSaveFile();
    setSaved(true);
    setTimeout(() => setSaved(false), 3200);
  };

  return (
    <div className="absolute inset-0 z-40 flex flex-col bg-[#0e0e11] anim-fade-in">
      <header className="border-b border-white/10 px-4 py-3 sm:px-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="font-display text-base font-bold tracking-wide sm:text-lg">
              МОИ РАБОТЫ · {customCount}/24 СВОИХ{videoCount > 0 && ` · ВИДЕО: ${videoCount}`}
              {hardLock && <span className="ml-1 rounded-full bg-white/10 px-2 py-0.5 align-middle font-mono2 text-[10px] font-normal text-white/60">только просмотр</span>}
            </h2>
            <p className="font-mono2 text-[10px] uppercase tracking-[0.25em] text-white/50">
              {hardLock ? "выставка опубликована · изменения запрещены" : "вставьте изображения и видео — они сразу появятся на стенах в 3D"}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Поиск: 07 · дуга · запад…"
              className="w-44 rounded-full border border-white/15 bg-white/5 px-4 py-2 text-xs outline-none placeholder:text-white/35 focus:border-[#c9a86a] sm:w-60" />
            <button onClick={onClose} className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10 transition hover:bg-white/25"><X size={16} /></button>
          </div>
        </div>

        {/* ---------- toolbar: публикация и защита ---------- */}
        {!hardLock && (
          <>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <button onClick={onSaveClick} disabled={saving}
                title="Упаковывает тур вместе со всеми фото и видео в один файл. После публикации никто не сможет менять работы и вставлять свои."
                className="flex items-center gap-2 rounded-full bg-[#c9a86a] px-5 py-2.5 text-xs font-bold text-black transition hover:bg-[#d9b878] disabled:opacity-60">
                <FileDown size={14} /> {saving ? "Публикация…" : saved ? "Опубликовано · файл скачан" : "Опубликовать выставку"}
              </button>
              <button onClick={() => void props.onExportJSON()} disabled={saving} title="Скачать JSON со всеми работами (резервная копия)"
                className="flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-4 py-2.5 text-xs font-semibold transition hover:bg-white/12 disabled:opacity-60">
                <Download size={14} /> Экспорт
              </button>
              <button onClick={() => !locked && importRef.current?.click()} title="Загрузить ранее сохранённый JSON"
                className={`flex items-center gap-2 rounded-full border border-white/15 px-4 py-2.5 text-xs font-semibold transition ${locked ? "cursor-not-allowed bg-white/5 text-white/35" : "bg-white/5 hover:bg-white/12"}`}>
                <FileUp size={14} /> Импорт
              </button>
              <button onClick={onLockClick} title={locked ? "Разблокировать по PIN" : hasPin() ? "Заблокировать" : "Установить PIN-код"}
                className={`flex items-center gap-2 rounded-full border px-4 py-2.5 text-xs font-semibold transition ${locked ? "border-[#c9a86a]/60 bg-[#c9a86a]/15 text-[#e8d5a8]" : "border-white/15 bg-white/5 hover:bg-white/12"}`}>
                {locked ? <Lock size={14} /> : <LockOpen size={14} />} {locked ? "Заблокировано" : hasPin() ? "Закрыть замок" : "PIN-замок"}
              </button>
            </div>
            <p className="mt-2 font-mono2 text-[10px] text-white/40">
              Файл публикации ≈ {publishSize} · все фото и видео вшиваются внутрь · после публикации менять работы и вставлять свои нельзя
            </p>
          </>
        )}
      </header>

      {/* ---------- locked banner ---------- */}
      {(locked || hardLock) && (
        <div className="flex items-center justify-center gap-2.5 border-b border-[#c9a86a]/25 bg-[#c9a86a]/10 px-4 py-2.5 text-center">
          <Lock size={13} className="shrink-0 text-[#c9a86a]" />
          <p className="text-[12px] text-[#e8d5a8]">
            {hardLock
              ? "Выставка опубликована: работы менять нельзя, вставлять свои нельзя — доступен только просмотр и 3D-тур."
              : "Редактирование заблокировано PIN-кодом — никто не сможет заменить работы или вставить свои."}
          </p>
          {!hardLock && locked && (
            <button onClick={onLockClick} className="shrink-0 rounded-full bg-[#c9a86a] px-4 py-1.5 text-[11px] font-bold text-black transition hover:bg-[#d9b878]">
              Разблокировать
            </button>
          )}
        </div>
      )}

      <div className="flex-1 overflow-y-auto thin-scroll p-4 sm:p-6">
        <div className="mx-auto grid max-w-7xl gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {list.map((a) => {
            const isCustom = (!!a.img && a.img !== a.defaultImg) || a.media === "video";
            const isVideo = a.media === "video";
            const missingVideo = isVideo && !a.img;
            return (
              <article key={a.id} className="group overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03] transition hover:border-[#c9a86a]/50">
                <div className="relative flex items-center justify-center bg-black/50 p-3">
                  {isVideo && a.img ? (
                    <video src={a.img} muted loop playsInline autoPlay controls
                      className="max-h-52 w-auto max-w-full rounded border-4 border-[#1c1c1f] object-contain shadow-lg"
                      style={{ aspectRatio: `${a.w} / ${a.h}` }} />
                  ) : (
                    <img src={urls.get(a.id)} alt={a.num}
                      className="max-h-52 w-auto max-w-full rounded border-4 border-[#1c1c1f] object-contain shadow-lg"
                      style={{ aspectRatio: `${a.w} / ${a.h}` }} draggable={false} />
                  )}
                  <span className="absolute left-3 top-3 rounded-full bg-black/75 px-2.5 py-1 font-mono2 text-[10px] text-[#c9a86a]">№ {a.num}</span>
                  {isVideo && a.img && <span className="absolute right-3 top-3 rounded-full bg-[#c9a86a] px-2.5 py-1 font-mono2 text-[10px] font-bold text-black">ВИДЕО</span>}
                  {missingVideo && <span className="absolute right-3 top-3 rounded-full bg-amber-400/90 px-2.5 py-1 font-mono2 text-[10px] font-bold text-black">НЕТ ФАЙЛА</span>}
                  {!isVideo && isCustom && <span className="absolute right-3 top-3 rounded-full bg-emerald-400/90 px-2.5 py-1 font-mono2 text-[10px] font-bold text-black">ВАША</span>}
                  {!isVideo && !a.img && <span className="absolute right-3 top-3 rounded-full bg-white/15 px-2.5 py-1 font-mono2 text-[10px] text-white/80">МЕСТО СВОБОДНО</span>}
                  <button onClick={() => onShowArt(a.id)} title="Смотреть в 3D"
                    className="absolute bottom-3 right-3 flex h-9 w-9 items-center justify-center rounded-full bg-[#c9a86a] text-black opacity-0 shadow-xl transition group-hover:opacity-100">
                    <Eye size={15} />
                  </button>
                </div>
                <div className="p-3.5">
                  <input
                    defaultValue={a.customTitle || a.title}
                    key={`${a.id}-${a.customTitle}-${locked}`}
                    readOnly={locked || hardLock}
                    onBlur={(e) => { const v = e.target.value.trim(); if (v && v !== (a.customTitle || a.title)) onTitle(a.id, v); }}
                    onKeyDown={(e) => { if (e.key === "Enter") (e.target as HTMLInputElement).blur(); }}
                    className={`w-full rounded-lg bg-transparent px-1 py-0.5 font-display text-[13px] font-semibold outline-none transition ${(locked || hardLock) ? "text-white/60" : "focus:bg-white/8 focus:ring-1 focus:ring-[#c9a86a]/50"}`}
                  />
                  <p className="mt-0.5 px-1 font-mono2 text-[10px] text-white/45">{a.zone} · {a.w.toFixed(2)}×{a.h.toFixed(2)} м</p>
                  {missingVideo && !(locked || hardLock) && (
                    <p className="mt-1.5 px-1 text-[11px] text-amber-200/80">Файл видео потерян (очищено хранилище). Вставьте его заново.</p>
                  )}
                  <div className="mt-2.5 flex gap-1.5">
                    {!(locked || hardLock) && (
                      <>
                        <button onClick={() => pick(a.id)} className="flex h-9 flex-1 items-center justify-center gap-1.5 rounded-full bg-white/10 text-[11px] font-bold transition hover:bg-[#c9a86a] hover:text-black">
                          <Upload size={13} /> {missingVideo ? "Вставить заново" : a.img ? "Заменить" : "Фото / видео"}
                        </button>
                        {isCustom && (
                          <button onClick={() => onReset(a.id)} title="Вернуть демо" className="flex h-9 w-9 items-center justify-center rounded-full border border-white/15 transition hover:bg-white/15">
                            <RotateCcw size={13} />
                          </button>
                        )}
                      </>
                    )}
                    <button onClick={() => onShowArt(a.id)} title="Показать в туре"
                      className={`flex h-9 items-center justify-center gap-1.5 rounded-full border border-white/15 transition hover:bg-white/15 ${(locked || hardLock) ? "flex-1 text-[11px] font-bold" : "w-9"}`}>
                      <Eye size={13} /> {(locked || hardLock) && "Смотреть в 3D"}
                    </button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
        <p className="mx-auto mt-6 max-w-2xl text-center font-mono2 text-[11px] leading-relaxed text-white/40">
          Фото: JPG / PNG · Видео: MP4 / WebM до {formatMB(MAX_VIDEO_BYTES)} · фото хранятся в браузере, видео — в IndexedDB ·
          для публикации всё упаковывается в один защищённый файл
        </p>
      </div>

      {/* ---------- PIN modal ---------- */}
      {pinMode && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm anim-fade-in" onClick={() => setPinMode(null)}>
          <div className="w-full max-w-sm rounded-2xl border border-white/15 bg-[#141417] p-6 anim-zoom-in" onClick={(e) => e.stopPropagation()}>
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-[#c9a86a]/15 text-[#c9a86a]">
              {pinMode === "set" ? <LockOpen size={20} /> : <Lock size={20} />}
            </div>
            <h3 className="mt-3 text-center font-display text-base font-bold">
              {pinMode === "set" ? "Установить PIN-код" : "Разблокировать"}
            </h3>
            <p className="mt-1 text-center text-xs text-white/55">
              {pinMode === "set"
                ? "После установки никто не сможет менять работы и вставлять свои без PIN."
                : "Введите PIN, чтобы снова разрешить изменения."}
            </p>
            <input
              type="password" inputMode="numeric" autoFocus value={pin}
              onChange={(e) => { setPin(e.target.value.replace(/\s/g, "")); setPinErr(""); }}
              onKeyDown={(e) => { if (e.key === "Enter") submitPin(); }}
              placeholder="••••"
              className="mt-4 w-full rounded-xl border border-white/15 bg-white/5 px-4 py-3 text-center text-xl tracking-[0.5em] outline-none placeholder:text-white/25 focus:border-[#c9a86a]"
            />
            {pinErr && <p className="mt-2 text-center text-xs text-red-300">{pinErr}</p>}
            <div className="mt-4 flex gap-2">
              <button onClick={() => setPinMode(null)} className="h-11 flex-1 rounded-full border border-white/15 text-xs font-semibold transition hover:bg-white/10">Отмена</button>
              <button onClick={submitPin} disabled={busy} className="h-11 flex-1 rounded-full bg-[#c9a86a] text-xs font-bold text-black transition hover:bg-[#d9b878] disabled:opacity-60">
                {busy ? "…" : pinMode === "set" ? "Заблокировать" : "Открыть"}
              </button>
            </div>
          </div>
        </div>
      )}

      <input ref={fileRef} type="file" accept="image/*,video/*" className="hidden" onChange={onFile} />
      <input ref={importRef} type="file" accept="application/json,.json" className="hidden" onChange={onImportFile} />
    </div>
  );
}
