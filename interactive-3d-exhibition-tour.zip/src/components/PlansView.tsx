import { useMemo, useState } from "react";
import { X, Footprints, Eye, RotateCw, Lightbulb, Ruler, Palette, ArrowUpRight } from "lucide-react";
import { ROOM, PARTITIONS, BENCHES, NODES, type ArtworkState } from "../data/gallery";
import { placeholderDataURL } from "../utils/textures";

interface Props {
  artworks: ArtworkState[];
  onClose: () => void;
  onPano: (nodeId: string) => void;
  onShowArt: (id: string) => void;
}

type Tab = "floor" | "walls" | "ceil" | "pano" | "mat";
const M2 = 30; // floor plan px per meter
const FW = 26 * M2, FH = 8 * M2; // horizontal format: length along X

const SX = (z: number) => ((z + 13) / 26) * FW;
const SY = (x: number) => ((x + 4) / 8) * FH;

function thumbs(artworks: ArtworkState[]) {
  const m = new Map<string, string>();
  for (const a of artworks) {
    m.set(a.id, a.img ?? placeholderDataURL(a.num, a.w, a.h, a.hue, a.customTitle || a.title));
  }
  return m;
}

export default function PlansView({ artworks, onClose, onPano, onShowArt }: Props) {
  const [tab, setTab] = useState<Tab>("walls");
  const th = useMemo(() => thumbs(artworks), [artworks]);
  const byId = useMemo(() => new Map(artworks.map((a) => [a.id, a])), [artworks]);

  const tabs: { id: Tab; label: string }[] = [
    { id: "walls", label: "Стены · развёртки" },
    { id: "floor", label: "Пол · план" },
    { id: "ceil", label: "Потолок · свет" },
    { id: "pano", label: "Панорамы 360°" },
    { id: "mat", label: "Материалы" },
  ];

  return (
    <div className="absolute inset-0 z-40 flex flex-col bg-[#0e0e11] anim-fade-in">
      {/* header */}
      <header className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 px-4 py-3 sm:px-6">
        <div>
          <h2 className="font-display text-base font-bold tracking-wide sm:text-lg">ПЛАНЫ ВЫСТАВОЧНОГО ПРОСТРАНСТВА</h2>
          <p className="font-mono2 text-[10px] uppercase tracking-[0.25em] text-white/50">горизонтальный формат · {ROOM.W} × {ROOM.L} × {ROOM.H} м · масштаб</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex gap-1 overflow-x-auto thin-scroll">
            {tabs.map((t) => (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={`whitespace-nowrap rounded-full px-4 py-2 text-xs font-semibold transition ${tab === t.id ? "bg-[#c9a86a] text-black" : "bg-white/8 text-white/70 hover:bg-white/15"}`}>
                {t.label}
              </button>
            ))}
          </div>
          <button onClick={onClose} className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10 transition hover:bg-white/25"><X size={16} /></button>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto thin-scroll">
        {tab === "walls" && <WallsTab th={th} byId={byId} onShowArt={onShowArt} />}
        {tab === "floor" && <FloorTab onPano={onPano} />}
        {tab === "ceil" && <CeilTab />}
        {tab === "pano" && <PanoTab artworks={artworks} onPano={onPano} />}
        {tab === "mat" && <MatTab />}
      </div>
    </div>
  );
}

/* ================= WALL ELEVATIONS ================= */
interface Item { id: string; u: number } // u = meters from left edge to artwork center

function Elevation({ title, sub, len, h, items, left, right, th, byId, onShowArt, door }: {
  title: string; sub: string; len: number; h: number; items: Item[];
  left: string; right: string;
  th: Map<string, string>; byId: Map<string, ArtworkState>;
  onShowArt: (id: string) => void; door?: boolean;
}) {
  const M = len > 10 ? 44 : 64;
  const Wpx = len * M, Hpx = h * M;
  const hangY = ROOM.HANG * M;
  return (
    <section className="rounded-2xl border border-white/10 bg-white/[0.03] p-4 sm:p-5">
      <div className="mb-3 flex flex-wrap items-baseline justify-between gap-2">
        <div>
          <h3 className="font-display text-sm font-bold">{title}</h3>
          <p className="font-mono2 text-[10px] uppercase tracking-widest text-white/45">{sub}</p>
        </div>
        <span className="font-mono2 text-[11px] text-[#c9a86a]">{len.toFixed(1)} м · H {h.toFixed(1)} м</span>
      </div>
      <div className="overflow-x-auto thin-scroll rounded-xl bg-[#141417] p-3">
        <div className="relative mx-auto" style={{ width: Wpx + 56, height: Hpx + 64 }}>
          {/* height ruler */}
          {[0, 1, ROOM.HANG, 2.7, h].filter((v, i, a) => a.indexOf(v) === i && v <= h).sort((a, b) => a - b).map((v) => (
            <div key={v} className="absolute font-mono2 text-[9px] text-white/40" style={{ left: 0, bottom: 34 + v * M - 6 }}>{v.toFixed(2)}</div>
          ))}
          {/* wall */}
          <div className="absolute rounded-t-sm border border-white/25 bg-gradient-to-b from-[#f5f2ec] to-[#e8e2d4]" style={{ left: 44, bottom: 34, width: Wpx, height: Hpx }}>
            {/* hang line */}
            <div className="absolute inset-x-0 border-t border-dashed border-[#c9a86a]/70" style={{ bottom: hangY }} />
            <span className="absolute right-1 font-mono2 text-[8px] text-[#8a6f3a]" style={{ bottom: hangY + 2 }}>центр 1.58</span>
            {/* ceiling line */}
            <div className="absolute inset-x-0 top-0 h-[3px] bg-[#0b0b0d]/70" />
            {door && (
              <div className="absolute bottom-0 -translate-x-1/2 bg-[#0b0b0d]" style={{ left: "50%", width: 2 * M, height: 2.6 * M }}>
                <div className="absolute inset-x-2 top-2 text-center font-mono2 text-[9px] tracking-[0.3em] text-white/70">ВХОД · 2.0 м</div>
              </div>
            )}
            {items.map(({ id, u }) => {
              const a = byId.get(id)!;
              const wpx = a.w * M, hpx = a.h * M;
              const bottom = (ROOM.HANG - a.h / 2) * M;
              return (
                <button key={id} onClick={() => onShowArt(id)} title={`${a.num} · ${a.customTitle || a.title}${a.media === "video" ? " · видео" : ""} — смотреть в 3D`}
                  className="group absolute border-[3px] border-[#17171a] bg-white shadow-[0_4px_14px_rgba(0,0,0,0.35)] transition hover:z-10 hover:scale-[1.04] hover:border-[#c9a86a]"
                  style={{ left: u * M - wpx / 2, bottom, width: wpx, height: hpx }}>
                  {a.media === "video" && a.img ? (
                    <video src={a.img} muted loop autoPlay playsInline className="h-full w-full object-cover" />
                  ) : (
                    <img src={th.get(id)} alt={a.num} className="h-full w-full object-cover" draggable={false} />
                  )}
                  <span className="absolute -top-5 left-1/2 -translate-x-1/2 whitespace-nowrap rounded bg-black/85 px-1.5 py-0.5 font-mono2 text-[9px] text-[#c9a86a] opacity-0 transition group-hover:opacity-100">
                    №{a.num} · {a.w.toFixed(2)}×{a.h.toFixed(2)}{a.media === "video" ? " · ВИДЕО" : ""}
                  </span>
                  <span className="absolute bottom-0.5 right-0.5 rounded bg-black/75 px-1 font-mono2 text-[8px] text-white/90">{a.media === "video" && a.img ? `${a.num} ▸` : a.num}</span>
                </button>
              );
            })}
          </div>
          {/* floor strip */}
          <div className="absolute rounded-b-sm border border-t-0 border-white/25" style={{ left: 44, bottom: 22, width: Wpx, height: 12, background: "repeating-linear-gradient(90deg,#c8a87e 0 6px,#b99063 6px 12px)" }} />
          {/* width dims */}
          <div className="absolute font-mono2 text-[10px] text-white/55" style={{ left: 44, bottom: 4 }}>◀ {left}</div>
          <div className="absolute font-mono2 text-[10px] text-white/55" style={{ right: 12, bottom: 4 }}>{right} ▶</div>
          <div className="absolute left-1/2 -translate-x-1/2 font-mono2 text-[10px] text-white/80" style={{ bottom: 4 }}>{len.toFixed(2)} м</div>
        </div>
      </div>
    </section>
  );
}

function WallsTab({ th, byId, onShowArt }: { th: Map<string, string>; byId: Map<string, ArtworkState>; onShowArt: (id: string) => void }) {
  // u coordinates (meters from left of elevation)
  const west: Item[] = [ // left=S(z+13) right=N(z-13): u = (13-z)
    { id: "AW04", u: 13 - -11.0 }, { id: "AW08", u: 13 - -6.5 }, { id: "AW14", u: 13 - -1.2 }, { id: "AW24", u: 13 - 9.6 },
  ];
  const east: Item[] = [ // left=N right=S: u = z+13
    { id: "AW15", u: -3.5 + 13 }, { id: "AW16", u: 0.5 + 13 }, { id: "AW23", u: 6.5 + 13 },
  ];
  const north: Item[] = [ // left=W right=E: u = x+4
    { id: "AW01", u: -2.2 + 4 }, { id: "AW02", u: 0 + 4 }, { id: "AW03", u: 2.2 + 4 },
  ];
  return (
    <div className="mx-auto max-w-6xl space-y-4 p-4 sm:p-6">
      <p className="flex items-center gap-2 text-xs text-white/55"><Ruler size={14} className="text-[#c9a86a]" /> Все развёртки — в горизонтальном формате. Клик по работе открывает её в 3D-туре с резким наездом камеры.</p>
      <Elevation title="Стена N · Северная (дальняя)" sub="глухая стена · главный акцент · 3 работы" len={8} h={4.2} items={north} left="ЗАПАД" right="ВОСТОК" th={th} byId={byId} onShowArt={onShowArt} />
      <Elevation title="Стена W · Западная" sub="несущая · 26 м · 4 работы" len={26} h={4.2} items={west} left="ЮГ · ВХОД" right="СЕВЕР" th={th} byId={byId} onShowArt={onShowArt} />
      <Elevation title="Стена E · Восточная" sub="несущая · 26 м · 3 работы" len={26} h={4.2} items={east} left="СЕВЕР" right="ЮГ · ВХОД" th={th} byId={byId} onShowArt={onShowArt} />
      <Elevation title="Стена S · Южная (входная)" sub="портал 2.0 × 2.6 м · без работ" len={8} h={4.2} items={[]} left="ВОСТОК" right="ЗАПАД" th={th} byId={byId} onShowArt={onShowArt} door />
      <div className="grid gap-4 lg:grid-cols-2">
        <Elevation title="Перегородка A · лицо (юг)" sub="3.6 м · вид от входа" len={3.6} h={2.7} items={[{ id: "AW05", u: 1.0 }, { id: "AW06", u: 2.6 }]} left="ЗАПАД" right="ВОСТОК" th={th} byId={byId} onShowArt={onShowArt} />
        <Elevation title="Перегородка A · оборот (север)" sub="вид из дальнего зала" len={3.6} h={2.7} items={[{ id: "AW07", u: 1.8 }]} left="ВОСТОК" right="ЗАПАД" th={th} byId={byId} onShowArt={onShowArt} />
        <Elevation title="Перегородка B · лицо (юг)" sub="1.6 м" len={1.6} h={2.7} items={[{ id: "AW09", u: 0.8 }]} left="ЗАПАД" right="ВОСТОК" th={th} byId={byId} onShowArt={onShowArt} />
        <Elevation title="Дуга · развёртка 3 сегментов" sub="8.7 м по дуге · выпуклая сторона" len={8.7} h={2.7} items={[{ id: "AW10", u: 1.45 }, { id: "AW11", u: 4.35 }, { id: "AW12", u: 7.25 }]} left="СЕВЕР" right="ЮГ" th={th} byId={byId} onShowArt={onShowArt} />
        <Elevation title="Дуга · оборот (коридор)" sub="вогнутая сторона" len={2.9} h={2.7} items={[{ id: "AW13", u: 1.45 }]} left="—" right="—" th={th} byId={byId} onShowArt={onShowArt} />
        <Elevation title="Пилон C · запад / восток" sub="2.2 м · две стороны" len={2.2} h={2.7} items={[{ id: "AW17", u: 0.58 }, { id: "AW18", u: 1.62 }]} left="СЕВЕР" right="ЮГ" th={th} byId={byId} onShowArt={onShowArt} />
        <Elevation title="Перегородка D · север" sub="3.6 м · вид из зала" len={3.6} h={2.7} items={[{ id: "AW19", u: 2.6 }, { id: "AW20", u: 1.0 }]} left="ВОСТОК" right="ЗАПАД" th={th} byId={byId} onShowArt={onShowArt} />
        <Elevation title="Перегородка D · юг + Пилон E" sub="входная группа" len={3.6} h={2.7} items={[{ id: "AW21", u: 1.8 }]} left="ЗАПАД" right="ВОСТОК" th={th} byId={byId} onShowArt={onShowArt} />
      </div>
      <Elevation title="Пилон E · север" sub="1.8 м · встречает входящих" len={1.8} h={2.7} items={[{ id: "AW22", u: 0.9 }]} left="ВОСТОК" right="ЗАПАД" th={th} byId={byId} onShowArt={onShowArt} />
    </div>
  );
}

/* ================= FLOOR PLAN ================= */
function FloorTab({ onPano }: { onPano: (id: string) => void }) {
  const pad = 46;
  return (
    <div className="mx-auto max-w-6xl p-4 sm:p-6">
      <p className="mb-3 flex items-center gap-2 text-xs text-white/55"><Footprints size={14} className="text-[#c9a86a]" /> План пола — горизонтальный формат: слева север (дальний зал), справа юг (вход). Клик по точке — панорама 360°.</p>
      <div className="overflow-x-auto thin-scroll rounded-2xl border border-white/10 bg-[#141417] p-4">
        <svg viewBox={`${-pad} ${-pad} ${FW + pad * 2} ${FH + pad * 2}`} className="mx-auto h-auto w-full min-w-[720px]">
          {/* wood floor */}
          <rect x={0} y={0} width={FW} height={FH} rx={4} fill="#b99063" />
          {Array.from({ length: 41 }).map((_, i) => (
            <line key={i} x1={0} y1={(FH / 40) * i} x2={FW} y2={(FH / 40) * i} stroke="rgba(70,45,22,0.28)" strokeWidth={1} />
          ))}
          {Array.from({ length: 14 }).map((_, i) => (
            <line key={`j${i}`} x1={(FW / 13) * i} y1={0} x2={(FW / 13) * i} y2={FH} stroke="rgba(70,45,22,0.18)" strokeWidth={1} />
          ))}
          {/* walls */}
          <rect x={-6} y={-6} width={FW + 12} height={FH + 12} rx={6} fill="none" stroke="#f5f2ec" strokeWidth={12} />
          <rect x={-6} y={-6} width={FW + 12} height={FH + 12} rx={6} fill="none" stroke="rgba(0,0,0,0.5)" strokeWidth={12} strokeDasharray="0" opacity={0.25} />
          {/* door gap south (right edge) */}
          <rect x={FW - 7} y={FH / 2 - 30} width={14} height={60} fill="#0e0e11" />
          <text x={FW + 12} y={FH / 2 + 4} fontSize={11} fill="#f5f2ec" fontFamily="JetBrains Mono, monospace">ВХОД 2.0</text>
          {/* benches */}
          {BENCHES.map((b, i) => {
            const alongZ = b.rotY === 0 ? b.d : b.w;
            const alongX = b.rotY === 0 ? b.w : b.d;
            return <rect key={i} x={SX(b.z) - (alongZ * M2) / 2} y={SY(b.x) - (alongX * M2) / 2} width={alongZ * M2} height={alongX * M2} rx={3} fill="#141416" stroke="#000" strokeWidth={1} />;
          })}
          {/* partitions as thick segments */}
          {PARTITIONS.map((p) => {
            const dx = Math.cos(p.rotY), dz = -Math.sin(p.rotY);
            const x1 = SX(p.z - (dz * p.w) / 2), y1 = SY(p.x - (dx * p.w) / 2);
            const x2 = SX(p.z + (dz * p.w) / 2), y2 = SY(p.x + (dx * p.w) / 2);
            return <line key={p.id} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#f5f2ec" strokeWidth={7} strokeLinecap="round" />;
          })}
          {/* tour route */}
          <polyline points={NODES.map((n) => `${SX(n.z)},${SY(n.x)}`).join(" ")} fill="none" stroke="#c9a86a" strokeWidth={1.5} strokeDasharray="6 5" opacity={0.8} />
          {/* nodes */}
          {NODES.map((n, i) => (
            <g key={n.id} onClick={() => onPano(n.id)} className="cursor-pointer">
              <circle cx={SX(n.z)} cy={SY(n.x)} r={13} fill="#c9a86a" stroke="#0b0b0d" strokeWidth={2} />
              <text x={SX(n.z)} y={SY(n.x) + 4.5} textAnchor="middle" fontSize={11} fontWeight={800} fill="#0b0b0d">{i + 1}</text>
              <text x={SX(n.z)} y={SY(n.x) - 17} textAnchor="middle" fontSize={10} fill="#fff" fontWeight={600} style={{ paintOrder: "stroke", stroke: "#0b0b0d", strokeWidth: 3 }}>{n.name}</text>
            </g>
          ))}
          {/* dims */}
          <line x1={0} y1={FH + 26} x2={FW} y2={FH + 26} stroke="rgba(255,255,255,0.5)" strokeWidth={1} />
          <text x={FW / 2} y={FH + 22} textAnchor="middle" fontSize={11} fill="#fff" fontFamily="JetBrains Mono, monospace">26.00 м</text>
          <line x1={-26} y1={0} x2={-26} y2={FH} stroke="rgba(255,255,255,0.5)" strokeWidth={1} />
          <text x={-30} y={FH / 2} textAnchor="middle" fontSize={11} fill="#fff" fontFamily="JetBrains Mono, monospace" transform={`rotate(-90 -30 ${FH / 2})`}>8.00 м</text>
          <text x={0} y={-14} fontSize={11} fill="rgba(255,255,255,0.6)" fontFamily="JetBrains Mono, monospace">◀ СЕВЕР · ДАЛЬНИЙ ЗАЛ</text>
          <text x={FW} y={-14} textAnchor="end" fontSize={11} fill="rgba(255,255,255,0.6)" fontFamily="JetBrains Mono, monospace">ВХОД · ЮГ ▶</text>
        </svg>
      </div>
      <div className="mt-3 grid gap-2 font-mono2 text-[11px] text-white/60 sm:grid-cols-3">
        <div className="rounded-xl bg-white/5 p-3">Площадь зала — <b className="text-white">208 м²</b> · периметр развески — <b className="text-white">≈ 96 м</b></div>
        <div className="rounded-xl bg-white/5 p-3">Перегородки — <b className="text-white">11 шт · H 2.70 м</b> · радиусная «Дуга» — 3 сегмента</div>
        <div className="rounded-xl bg-white/5 p-3">Маршрут — <b className="text-[#c9a86a]">пунктир</b> · 6 точек · движение WASD / стрелки / джойстик</div>
      </div>
    </div>
  );
}

/* ================= CEILING ================= */
function CeilTab() {
  const pad = 46;
  return (
    <div className="mx-auto max-w-6xl p-4 sm:p-6">
      <p className="mb-3 flex items-center gap-2 text-xs text-white/55"><Lightbulb size={14} className="text-[#c9a86a]" /> План потолка H 4.20 м: LED-линии, трековые шины и акцентные споты 3000K на каждую работу.</p>
      <div className="overflow-x-auto thin-scroll rounded-2xl border border-white/10 bg-[#141417] p-4">
        <svg viewBox={`${-pad} ${-pad} ${FW + pad * 2} ${FH + pad * 2}`} className="mx-auto h-auto w-full min-w-[720px]">
          <rect x={0} y={0} width={FW} height={FH} rx={4} fill="#1c1c20" stroke="#f5f2ec" strokeWidth={10} />
          {/* LED strips at x=±2.3 */}
          {[2.3, -2.3].map((x) => (
            <line key={x} x1={SX(-12)} y1={SY(x)} x2={SX(12)} y2={SY(x)} stroke="#fff3d6" strokeWidth={4} strokeLinecap="round" opacity={0.95} />
          ))}
          {/* tracks at x=±1.3 */}
          {[1.3, -1.3].map((x) => (
            <g key={x}>
              <line x1={SX(-11.5)} y1={SY(x)} x2={SX(11.5)} y2={SY(x)} stroke="#000" strokeWidth={5} />
              {Array.from({ length: 11 }).map((_, i) => {
                const z = -11 + i * 2.2;
                return <circle key={i} cx={SX(z)} cy={SY(x)} r={3.4} fill="#ffedc4" stroke="#c9a86a" strokeWidth={1} />;
              })}
            </g>
          ))}
          {/* downlights */}
          {[[-9], [-3], [3], [9]].map(([z]) => (
            <g key={z}>
              <circle cx={SX(z)} cy={SY(0)} r={9} fill="none" stroke="#c9a86a" strokeWidth={1.5} strokeDasharray="3 3" />
              <circle cx={SX(z)} cy={SY(0)} r={3} fill="#c9a86a" />
            </g>
          ))}
          <text x={FW / 2} y={FH + 24} textAnchor="middle" fontSize={11} fill="#fff" fontFamily="JetBrains Mono, monospace">26.00 м · H 4.20 м</text>
          <text x={0} y={-14} fontSize={11} fill="rgba(255,255,255,0.6)" fontFamily="JetBrains Mono, monospace">◀ СЕВЕР</text>
          <text x={FW} y={-14} textAnchor="end" fontSize={11} fill="rgba(255,255,255,0.6)" fontFamily="JetBrains Mono, monospace">ЮГ ▶</text>
        </svg>
      </div>
      <div className="mt-3 grid gap-2 text-[12px] sm:grid-cols-4">
        {[
          { c: "#fff3d6", t: "LED-линии 2 × 24 м · 4000K · заливка" },
          { c: "#ffedc4", t: "Трековые головы 22 шт · поворотные" },
          { c: "#c9a86a", t: "Даунлайты 4 шт · проход · 2 с тенью" },
          { c: "#f5f2ec", t: "Акцентные споты 24 шт · по 1 на работу" },
        ].map((l, i) => (
          <div key={i} className="flex items-center gap-2.5 rounded-xl bg-white/5 p-3 text-white/70">
            <span className="h-3.5 w-3.5 shrink-0 rounded-full" style={{ background: l.c, boxShadow: `0 0 10px ${l.c}` }} />{l.t}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ================= PANORAMAS ================= */
function PanoTab({ artworks, onPano }: { artworks: ArtworkState[]; onPano: (id: string) => void }) {
  return (
    <div className="mx-auto max-w-6xl p-4 sm:p-6">
      <p className="mb-4 flex items-center gap-2 text-xs text-white/55"><RotateCw size={14} className="text-[#c9a86a]" /> Шесть фотореалистичных панорам 360° — по одной на каждый зал. Камера встаёт в точку и медленно вращается; можно осматриваться мышью, пальцем или гироскопом.</p>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {NODES.map((n, i) => {
          const near = artworks
            .map((a) => ({ a, d: Math.hypot(a.x - n.x, a.z - n.z) }))
            .filter((x) => x.d < 8.5)
            .sort((p, q) => p.d - q.d)
            .slice(0, 6);
          return (
            <div key={n.id} className="group overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03] transition hover:border-[#c9a86a]/60">
              {/* schematic 360 strip */}
              <div className="relative h-28 overflow-hidden bg-gradient-to-b from-[#232329] via-[#17171b] to-[#0e0e11]">
                <div className="absolute inset-x-0 top-6 flex justify-center gap-[3px] px-6">
                  {near.map(({ a }) => (
                    <div key={a.id} className="h-12 flex-1 rounded-[2px] border border-white/30 bg-white/10" title={`№${a.num}`} />
                  ))}
                </div>
                <div className="absolute inset-x-8 bottom-4 h-[3px] rounded bg-[#c9a86a]/60" />
                <span className="absolute left-3 top-3 rounded-full bg-black/70 px-2.5 py-1 font-mono2 text-[10px] text-[#c9a86a]">360° · {n.id}</span>
                <Eye size={16} className="absolute right-3 top-3 text-white/40" />
              </div>
              <div className="p-4">
                <div className="flex items-baseline justify-between">
                  <h3 className="font-display text-sm font-bold">{i + 1}. {n.name}</h3>
                  <span className="font-mono2 text-[10px] text-white/45">{n.sub}</span>
                </div>
                <p className="mt-1.5 font-mono2 text-[10px] leading-relaxed text-white/50">
                  В КАДРЕ: {near.map((x) => `№${x.a.num}`).join(" · ") || "—"}
                </p>
                <button onClick={() => onPano(n.id)} className="mt-3 flex w-full items-center justify-center gap-2 rounded-full bg-white/10 py-2.5 text-xs font-bold transition group-hover:bg-[#c9a86a] group-hover:text-black">
                  Открыть панораму <ArrowUpRight size={14} />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ================= MATERIALS ================= */
function MatTab() {
  const mats = [
    { name: "Пол · Дуб натуральный", spec: "массив / инженерная доска · лак матовый", sw: "repeating-linear-gradient(90deg,#cfa878 0 10px,#c09a6a 10px 14px,#b78e5f 14px 24px)", dark: false },
    { name: "Стены · Белый куб", spec: "RAL 9003 · матовая · моющаяся", sw: "linear-gradient(135deg,#f7f4ee,#e9e3d6)", dark: false },
    { name: "Перегородки · H 2.70", spec: "ГКЛ + шпатлёвка · теневой шов сверху", sw: "linear-gradient(135deg,#f5f2ec 80%,#cfc8b8 80% 84%,#f5f2ec 84%)", dark: false },
    { name: "Скамьи · Чёрная кожа", spec: "4 шт · сталь шлифованная", sw: "linear-gradient(135deg,#1b1b1f,#0c0c0e)", dark: true },
    { name: "Рамы · Алюминий", spec: "чёрный профиль 30 мм · музейное стекло", sw: "linear-gradient(135deg,#2a2a2e,#101013)", dark: true },
    { name: "Свет · 3000K тёплый", spec: "CRI 95+ · споты + треки + LED", sw: "radial-gradient(circle at 50% 40%,#fff6dd,#c9a86a 60%,#5a4a28)", dark: true },
  ];
  return (
    <div className="mx-auto max-w-6xl p-4 sm:p-6">
      <p className="mb-4 flex items-center gap-2 text-xs text-white/55"><Palette size={14} className="text-[#c9a86a]" /> Новый дизайн в стиле исходного макета: белый куб, тёплый дуб, чёрные акценты, радиусная «Дуга».</p>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {mats.map((m) => (
          <div key={m.name} className="overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03]">
            <div className="flex h-28 items-end p-3" style={{ background: m.sw }}>
              <span className={`rounded-full px-2.5 py-1 font-mono2 text-[10px] ${m.dark ? "bg-black/60 text-white/85" : "bg-white/70 text-black/70"}`}>swatch · 1:1</span>
            </div>
            <div className="p-4">
              <h3 className="font-display text-[13px] font-bold">{m.name}</h3>
              <p className="mt-1 font-mono2 text-[11px] text-white/50">{m.spec}</p>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-4 rounded-2xl border border-[#c9a86a]/30 bg-[#c9a86a]/8 p-5">
        <h3 className="font-display text-sm font-bold text-[#c9a86a]">Концепция освещения</h3>
        <p className="mt-2 text-[13px] leading-relaxed text-white/70">
          Зал работает как «белый куб» с тёплым ядром: общий свет дают два LED-реза в потолке и четыре даунлайта над проходом,
          каждую из 24 работ ведёт собственный акцентный спот 3000K под углом 30°. Трековые шины позволяют перевешивать экспозицию
          без пересвета. Экспозиция — 3000K, CRI 95+: бумага и печать выглядят как при дневном музейном свете.
        </p>
      </div>
    </div>
  );
}
